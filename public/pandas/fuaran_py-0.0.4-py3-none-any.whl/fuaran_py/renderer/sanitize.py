"""Render-time injection-safety floor — the Python port of ``Sanitize.fs``.

The wire decoder is best-effort: a malicious AI emission can smuggle an
``ExtraAttributes`` key, an ``onerror=`` handler inside markdown source, or a
``javascript:`` href through the decode path. This module is the last line of
defence before bytes reach a browser's HTML parser, and it mirrors the F#/TS
renderers' posture seam-for-seam so the three hosts cannot drift on safety
(see ``fuaran-dotnet/SANITIZATION.md``):

1. **ExtraAttributes** — drop ``on*`` handlers, ``style``, and anything outside
   the ``data-*`` / ``aria-*`` allowlist; reject values carrying control bytes
   or angle brackets.
2. **URL props** — block ``javascript:`` / ``vbscript:`` / ``file:`` and any
   unknown scheme; allow ``http`` / ``https`` / ``mailto`` / ``tel`` / ``ftp`` /
   ``sftp`` + same-origin relative paths.
3. **Markdown raw HTML** — strip dangerous element blocks, inline ``on*=``
   handlers, and ``javascript:`` / ``vbscript:`` URLs from rendered markdown.

The ``Custom`` host-renderer registry is a host trust boundary, not an
AI-emission surface — this module does not police it (and ``fuaran-py``'s
baseline renderer ships no host-registry seam; ``Custom`` renders an inert
labelled placeholder).
"""

from __future__ import annotations

import re
import string

# ── Case folding ────────────────────────────────────────────────────────────

_ASCII_FOLD = str.maketrans(string.ascii_uppercase, string.ascii_lowercase)


def _ascii_lower(s: str) -> str:
    """ASCII-only lowercase — length-preserving, which ``str.lower()`` is not.

    ``"İ".lower()`` is two code points (U+0069 U+0307), so every place below
    that searches a case-folded COPY and splices the resulting indices back
    into the ORIGINAL string depends on a fold that cannot change length. A
    locale-aware fold silently shifts the removal window and leaves a fragment
    of the element it meant to remove. The tag / scheme / protocol vocabulary
    this module matches is ASCII, so an ASCII-only fold loses no matches.
    """
    return s.translate(_ASCII_FOLD)


# ── ExtraAttributes key/value sanitization ─────────────────────────────────

_CONTROL_OR_ANGLE = re.compile(r"[\x00-\x08\x0a-\x1f<>]")


_SAFE_ATTRIBUTE_NAME_CHARS = frozenset(string.ascii_letters + string.digits + "-")


def is_safe_attribute_name(name: str) -> bool:
    """Positive character allowlist for an HTML attribute NAME: ``[A-Za-z0-9-]``.

    Everything else — ``=``, quotes, backtick, ``<``, ``>``, ``/``, space, tab,
    newline, C0 controls, any non-ASCII byte — is rejected.

    This is a **rejection** gate, not an escape, because HTML has no escape for an
    illegal character in an attribute name: a space inside a name simply starts a
    NEW attribute and an ``=`` starts its value. So
    ``data-x=1 onmouseover=alert(1) z`` is not a mangled attribute name — it is
    three attributes, one of them a live event handler. Renderers escape attribute
    *values*, never *names*, so dropping the entry is the only sound response.

    Exported so an emission site can re-check it as defence in depth rather than
    trusting upstream validation alone.
    """
    if not name:
        return False
    return all(ch in _SAFE_ATTRIBUTE_NAME_CHARS for ch in name)


def is_allowed_extra_attribute_key(key: str) -> bool:
    """The ``data-*`` / ``aria-*`` allowlist, with an explicit ``on*`` / ``style`` reject.

    Plus :func:`is_safe_attribute_name` over the whole trimmed key — without it a
    key like ``data-x=1 onmouseover=alert(1) z`` satisfies the ``data-`` prefix and
    smuggles a live event handler into rendered HTML.

    The predicate judges the **trimmed** form, so a caller using it directly must
    trim before emission too.
    """
    if key is None:
        return False
    trimmed = key.strip()
    if trimmed == "":
        return False
    if trimmed.lower().startswith("on"):
        # Any `on*` event-handler attribute, even hand-constructed.
        return False
    if trimmed.lower() == "style":
        # CSS-injection vector (`expression()`, `url(javascript:…)`).
        return False
    if not is_safe_attribute_name(trimmed):
        # Attribute-NAME injection: any character that could terminate the name
        # and open a second attribute at the emission site.
        return False
    return trimmed.startswith("data-") or trimmed.startswith("aria-")


def is_safe_extra_attribute_value(value: str) -> bool:
    """Reject control / NUL bytes and angle brackets (``\\t`` is allowed)."""
    if value is None:
        return False
    return _CONTROL_OR_ANGLE.search(value) is None


def sanitize_extra_attributes(attrs: dict[str, str]) -> dict[str, str]:
    """Filter a candidate attribute map down to entries that pass both predicates.

    The re-key is load-bearing: the predicate judges ``key.strip()``, so emitting
    the untrimmed key would emit something the gate never inspected.
    """
    return {
        k.strip(): v for k, v in attrs.items() if is_allowed_extra_attribute_key(k) and is_safe_extra_attribute_value(v)
    }


# ── URL-scheme sanitization ─────────────────────────────────────────────────

_ALLOWED_URL_SCHEMES = frozenset({"http", "https", "mailto", "tel", "ftp", "sftp"})
_REJECTED_URL_SCHEMES = frozenset({"javascript", "vbscript", "file"})


def _extract_scheme(url: str) -> str | None:
    """Return the lowercased scheme, or ``None`` for a relative / fragment URL.

    Looks for the first ``:`` before any ``/`` ``?`` ``#``. Whitespace and
    control chars inside the scheme region are stripped first so ``java\\tscript``,
    ``  javascript`` and ``JAVASCRIPT`` all classify as ``javascript``.
    """
    colon_idx = -1
    slash_idx = -1
    for i, ch in enumerate(url):
        if ch == ":":
            colon_idx = i
            break
        if ch in "/?#":
            slash_idx = i
            break
    if colon_idx < 0 or (0 <= slash_idx < colon_idx):
        return None
    raw = url[:colon_idx]
    cleaned = "".join(ch for ch in raw if ord(ch) > 0x20)
    return cleaned.strip().lower()


def _is_protocol_relative(url: str) -> bool:
    """A protocol-relative URL: ``//host/path`` and the forms browsers fold into it.

    WHATWG URL parsing treats ``\\`` as ``/`` for special schemes, so ``\\\\host``,
    ``/\\host`` and ``\\/host`` all resolve exactly as ``//host`` does.

    These carry no scheme, so the schemeless branch below would otherwise admit
    them — but the browser resolves them against the CURRENT page's scheme and
    lands on an OFF-ORIGIN host, defeating the same-origin intent that makes a
    schemeless URL safe. On an ``href`` that is off-origin navigation; on an
    image ``src`` it is an off-origin request that leaks the Referer.
    """
    return len(url) >= 2 and url[0] in "/\\" and url[1] in "/\\"


_TAB_LF_CR = ("\t", "\n", "\r")


def _normalize_url_for_floor(url: str) -> str:
    """§19 rule 1 — normalise exactly as the WHATWG URL Standard's basic URL parser does.

    Two ordered, ASCII-exact steps applied before the parser parses anything:

    1. remove leading and trailing **C0 control or space** — all of U+0000–U+0020,
       not merely the whitespace subset;
    2. remove every U+0009 / U+000A / U+000D from anywhere in what remains.

    Deliberately **not** :meth:`str.strip`. A native trim answers a different
    question in every language — ``str.strip`` also removes U+001C–U+001F where
    .NET, JS, Go and Rust do not; JS alone keeps U+0085 NEL where the other four
    drop it — and all of them remove non-ASCII whitespace (U+00A0, U+2028, …) that
    the parser keeps. The floor's whole purpose is that a tree vetted on one host
    is safe on another, so the normalisation is defined by the parser that will
    actually consume the string, not by the host's standard library.

    Step 2 is those three code points **only**: the parser removes U+000B and
    U+000C at the edges (step 1) and *keeps* them in the interior, so
    ``/<VT>/host/x`` is an ordinary same-origin path and must stay one.
    """
    lo, hi = 0, len(url)
    while lo < hi and url[lo] <= " ":
        lo += 1
    while hi > lo and url[hi - 1] <= " ":
        hi -= 1
    return "".join(ch for ch in url[lo:hi] if ch not in _TAB_LF_CR)


def sanitize_url(url: str) -> str | None:
    """Return the URL if its scheme is accepted, else ``None`` (default-deny).

    The input is first normalised per §19 rule 1 (see :func:`_normalize_url_for_floor`),
    and that normalised form is also what is **emitted** on acceptance — so an
    accepted URL carrying an interior tab loses it, which is what the browser would
    have parsed anyway.
    """
    if url is None:
        return None
    trimmed = _normalize_url_for_floor(url)
    if trimmed == "":
        # Empty href/src — pass through (a same-page link, documented HTML behaviour).
        return trimmed
    scheme = _extract_scheme(trimmed)
    if scheme is None:
        if _is_protocol_relative(trimmed):
            # Off-origin despite carrying no scheme.
            return None
        # No scheme → relative / fragment / same-origin. Allowed.
        return trimmed
    if scheme in _REJECTED_URL_SCHEMES:
        return None
    if scheme in _ALLOWED_URL_SCHEMES:
        return trimmed
    # Unknown scheme — reject by default (conservative; adding one is additive).
    return None


def sanitize_url_or_blank(url: str) -> str:
    """The URL if accepted, else the literal ``"about:blank"`` (keeps the link valid)."""
    result = sanitize_url(url)
    return result if result is not None else "about:blank"


# ── Markdown raw-HTML sanitization ──────────────────────────────────────────

_DANGEROUS_ELEMENTS = ("script", "iframe", "object", "embed", "form", "link", "meta")
_EVENT_HANDLER = re.compile(r"\son[a-zA-Z]+(\s*=\s*(\"[^\"]*\"|'[^']*'|[^\s>]*))?", re.IGNORECASE)
# A `<...>` start-tag span. The event-handler sweep runs only *inside* these, never
# over body text — see `_strip_event_handlers`.
_TAG_SPAN = re.compile(r"<[^>]*>")
_DANGEROUS_PROTOCOL = re.compile(r"(?i)(javascript|vbscript):")


def _strip_event_handlers(html: str) -> str:
    """Remove ``on*=`` handlers, but only inside tag interiors.

    The tag-interior anchor is load-bearing: the ``\\son<letter>`` pattern also
    matches the leading-whitespace-``on`` of ordinary English words — "one",
    "only", "once", "onto", "online", … — so running the regex globally deletes
    those words from body text. Because the render path constrains the input to
    the deterministic markdown emitter's output (raw HTML already escaped), a
    real event-handler attribute only appears inside a tag the renderer emitted,
    so scoping the sweep to ``<...>`` spans is both correct and false-positive-free.
    """
    return _TAG_SPAN.sub(lambda m: _EVENT_HANDLER.sub("", m.group(0)), html)


def sanitize_markdown_html(html: str) -> str:
    """Strip dangerous element blocks, ``on*=`` handlers, and script-scheme URLs.

    Approximate (not a full HTML parser): the render path constrains the input
    to the baseline markdown emitter's output, so a substring/regex sweep is
    sufficient defence in depth. Hosts needing DOMPurify-grade sanitization
    layer it consumer-side — this is the floor, not the ceiling.
    """
    if not html:
        return ""
    result = html
    for tag in _DANGEROUS_ELEMENTS:
        open_tag = "<" + tag
        close_tag = "</" + tag + ">"
        while True:
            # ASCII-only fold: the indices below splice into `result`, so the
            # searched copy must stay index-aligned with it (see `_ascii_lower`).
            folded = _ascii_lower(result)
            i = folded.find(open_tag)
            if i < 0:
                break
            j = folded.find(close_tag, i)
            if j >= 0:
                result = result[:i] + result[j + len(close_tag) :]
            else:
                end = result.find(">", i)
                result = result[:i] + (result[end + 1 :] if end >= 0 else "")
    result = _strip_event_handlers(result)
    result = _DANGEROUS_PROTOCOL.sub("about:blank", result)
    return result
