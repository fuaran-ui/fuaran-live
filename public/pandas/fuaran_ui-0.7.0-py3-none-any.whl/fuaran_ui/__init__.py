"""fuaran-ui — a headless Python host of the Fuaran UI wire format.

A dependency-light, idiomatic-Python reference implementation of the canonical
Fuaran UI wire format (``WIRE_FORMAT.md``): decode / encode for the ``Node`` tree
and the ``TreeOp`` algebra, plus a pre-emit validator. It is a *sibling*
reference implementation built to the language-neutral spec + conformance
corpus, not a transpile of any other host.

Canonical imports::

    from fuaran_ui import decode_node, encode_node, decode_op, encode_op
    from fuaran_ui import decode_dag_record, encode_dag_record   # branching op-stream
    from fuaran_ui import Ok, Err, DecodeError
    from fuaran_ui.renderer import render_html      # optional headless renderer
    from fuaran_ui.client import FuaranClient, FuaranSession   # generation-endpoint client
"""

from __future__ import annotations

from .dag import DagOpRecord, DagResultEnvelope, decode_dag_record, encode_dag_record
from .function import (
    EXACT,
    SUBSUMES,
    ComposePath,
    FunctionEntry,
    FunctionRegistry,
    NoPath,
    SigEntry,
    Signature,
    SignatureQuery,
    function_entry,
    slot_hole,
    value_hole,
)
from .merge import (
    MergeAuthor,
    MergeConflict,
    MergeConflicts,
    MergeOk,
    MergeResult,
    MergeSide,
    Primary,
    Secondary,
    encode_envelope,
    merge3,
    merge3_way_lenient,
    merge3_way_with_author,
    merge_3way,
)
from .model import Arr, Node, Obj, from_json
from .ops import decode_op, diff, encode_op
from .result import (
    CODES,
    DecodeError,
    DecodeResult,
    Err,
    Ok,
)
from .schema import decode_node, encode_node
from .validator import Finding, validate_node

#: Distribution version. Kept in step with ``pyproject.toml``; the packaging-contract
#: test in ``tests/`` fails if the two disagree, so this is a pin rather than a copy.
__version__ = "0.7.0"

__all__ = [
    "decode_node",
    "encode_node",
    "decode_op",
    "encode_op",
    "decode_dag_record",
    "encode_dag_record",
    "DagOpRecord",
    "DagResultEnvelope",
    "merge_3way",
    "merge3",
    "merge3_way_with_author",
    "merge3_way_lenient",
    "MergeOk",
    "MergeConflicts",
    "MergeConflict",
    "MergeSide",
    "MergeResult",
    "encode_envelope",
    "MergeAuthor",
    "Primary",
    "Secondary",
    "diff",
    "FunctionRegistry",
    "FunctionEntry",
    "SigEntry",
    "Signature",
    "SignatureQuery",
    "ComposePath",
    "NoPath",
    "value_hole",
    "slot_hole",
    "function_entry",
    "SUBSUMES",
    "EXACT",
    "validate_node",
    "Finding",
    "Node",
    "Obj",
    "Arr",
    "from_json",
    "Ok",
    "Err",
    "DecodeError",
    "DecodeResult",
    "CODES",
    "__version__",
]
