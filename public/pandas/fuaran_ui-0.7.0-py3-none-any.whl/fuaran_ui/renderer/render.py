"""Server-HTML renderer over the decoded ``Node`` tree (Phase 239 baseline).

A pure string-HTML renderer: it walks the structural decoded tree
(:mod:`fuaran_ui.model`) and emits the reference ``fuaran-*`` class vocabulary so
the byte-copied ``content/fuaran-reference.css`` styles the output exactly as it
styles the F# and TypeScript hosts. It is the no-dependency baseline that makes
a Python web host (e.g. FastAPI) render Fuaran chrome end-to-end with no
client runtime — the analogue of the F# SSR renderer (Phase 140).

Server semantics mirror that precedent: no runtime, no dispatch. ``Action``-
bearing nodes render inert (a ``Button`` is dead until a client hydrates it; a
``Link`` is a real crawlable ``<a href>``). ``Static`` bindings resolve to their
value; other bindings resolve from a host-supplied ``sources`` map or fall back
to the em-dash placeholder. A visualisation this host cannot paint (``Map``, a
not-yet-lowered ``Chart``) renders a deterministic placeholder, never a blank.

**Bound-grid posture (Phase 668) — completeness.** A data-bound ``DataGrid``
whose columns declare a *declarative* projection renders its rows as a real
table, resolved through the same render-time compute path every other bound slot
uses (Phase 648); it does not degrade to a row-count placeholder. The boundary
that remains is declared rather than incidental — see :meth:`Renderer._data_grid`.

**Ambient destination policy (WIRE_FORMAT §14.1).** Every ``href`` / ``src`` this
renderer emits is checked against the render context's
:attr:`Renderer.egress_policy`, which **defaults to deny-non-local**. The seam
shipped before this — the policy functions existed and every emission site still
called ``sanitize_url_or_blank``, so a decoded tree's egress was policy-checked
only where a host had remembered to ask. A guarantee that holds where it is
remembered is not a guarantee, which is why the policy lives on the context every
render already threads rather than on the emission helpers.

The renderer emits the **body fragment** only — the host owns ``<html>`` /
``<head>`` / the ``<link>`` to :func:`fuaran_ui.renderer.reference_css_path`.
"""

from __future__ import annotations

import math
from collections.abc import Callable, Sequence

from ..model import Arr, Node, Obj, Value
from . import markdown
from .bindings import (
    BindingSourcesLike,
    as_sources,
    format_number,
    is_node_visible,
    render_text,
    resolve_binding,
    resolve_display_string,
    resolve_scalar_bool,
    resolve_scalar_number,
    resolve_scalar_text,
    resolve_source,
    select_switch_case,
)
from .egress import (
    DENY_NON_LOCAL_EGRESS,
    EgressClass,
    EgressPolicy,
    sanitize_embed_src_for_egress,
    sanitize_url_for_egress,
)
from .html import element, escape_text, text_element, void_element
from .sanitize import (
    sanitize_css_value_for_slot,
    sanitize_link_anchor,
    sanitize_paint_value,
)
from .seeds import with_state_seeds
from .theme import (
    grid_row_interactive_class,
    node_class_name,
    text_direction_attrs,
    trend_sentiment,
)

# Unresolved-binding placeholder — matches the F# SSR renderer's em-dash.
_EM_DASH = "—"


def metric_value_text(fields: dict[str, Value], value: object) -> str:
    """The TEXT a ``Metric``'s numeric value slot reads.

    The resolved number in the slot's declared format, or the em-dash when the
    binding did not resolve — which ``WIRE_FORMAT.md`` §24.8 now reaches for a
    bare ``State`` as well as for an unwritten ``Query``.

    Extracted from ``_metric`` in Phase 1690 so the render-text conformance leg
    asserts the projection this renderer actually emits, rather than a second
    copy of it: a checker that spells the em-dash itself agrees with the
    renderer on the day it is written and never again. It takes the
    ALREADY-RESOLVED value, so the one call site that also needs the resolution
    for its loading branch does not resolve twice.
    """
    return format_number(fields.get("format"), value) if value is not None else _EM_DASH


# ── FormField.rule → the platform's own constraint attributes (fuaran#864) ───
#
# A static emitter MUST project a declared rule into the PLATFORM's constraint
# vocabulary, so the platform — here, the browser receiving this HTML — is what
# enforces it: `pattern` carries ECMA-262 source with HTML `pattern` semantics
# (implicitly anchored to the whole value), and `minlength` / `maxlength` are the
# native length bounds. Emitted in the same order as the reference server
# renderer, the Phase 801 discipline: a progressive-enhancement script that reads
# one host's markup reads the other's unchanged.
#
# TWO RECORDED LIMITS, each a declaration rather than a silent drop.
#
# `compare` has NO HTML equivalent. It is emitted as a
# `data-fuaran-field-compare` DECLARATION — matching the reference renderers'
# marker — so a reader can see the constraint was carried and not dropped, and it
# is NOT claimed as coverage: nothing in the platform reads that attribute, and
# this emitter produces inert markup with no gate of its own. A cross-field
# comparison is enforced by a rendering host's submit gate and, non-bypassably,
# by a server-side re-check.
#
# And `type` is emitted only WHERE A FORMAT RULE DECLARES IT. The reference host
# always emits a control `type`; this host's baseline form projection never has,
# so emitting `type="text"` now would change the bytes of every form this host
# has ever rendered in order to state the default. The narrowing is deliberate:
# a declared `format` retypes the control, an undeclared one leaves the markup
# exactly as it was. The wider control-typing gap is the baseline's, not this
# slot's, and is recorded in the README's form-field note.

_RULE_FORMAT_INPUT_TYPES = {"email": "email", "url": "url", "tel": "tel"}


def _field_rule_attrs(rule: Value, control_tag: str | None) -> list[tuple[str, str]]:
    """The HTML constraint attributes a decoded ``FormField.rule`` projects to."""
    if not isinstance(rule, Obj):
        return []
    out: list[tuple[str, str]] = []
    fmt = rule.fields.get("format")
    if isinstance(fmt, str) and fmt in _RULE_FORMAT_INPUT_TYPES:
        out.append(("type", _RULE_FORMAT_INPUT_TYPES[fmt]))
    pattern = rule.fields.get("pattern")
    # `<textarea>` has no `pattern` attribute in HTML — emit nothing rather than
    # an attribute the platform ignores.
    if isinstance(pattern, str) and control_tag != "TextArea":
        out.append(("pattern", pattern))
    for slot, attr in (("minLength", "minlength"), ("maxLength", "maxlength")):
        bound = rule.fields.get(slot)
        if isinstance(bound, int) and not isinstance(bound, bool):
            out.append((attr, str(bound)))
    compare = rule.fields.get("compare")
    if isinstance(compare, Obj):
        op = compare.fields.get("op")
        against = compare.fields.get("against")
        key = against.fields.get("key") if isinstance(against, Obj) and against.tag == "State" else None
        if isinstance(op, str):
            out.append(("data-fuaran-field-compare", f"{op}:{key if isinstance(key, str) else ''}"))
    return out


def _a11y_name(value: Value, sources: BindingSourcesLike | None) -> str | None:
    """Resolve an accessibility name slot to its display string.

    The canonical form is a ``Binding[str]``, resolved through the SCALAR path
    (Phase 1665) exactly as every other display slot is: a ``Transform`` or an
    ``Expr`` yields its 1x1 result cell, and every other case reads the host
    sources (``Static`` inline, every keyed case from the map, an unwritten
    ``Selection`` / ``Filter`` / ``State`` from its declared ``defaultValue``)
    and is rendered by the same display form the text slots use — so a number or
    bool reaching a name slot reads the way it reads everywhere else, and a
    structured value yields ``None``. WIRE_FORMAT's accessibility-trait render
    obligations state the rule; the corpus pins it with
    ``nodes/a11y-wrapper-transform-label`` and the ``behaviour`` vectors in
    ``a11y-contract.json``.

    A BARE STRING is ALSO accepted, deliberately, as a LENIENT SHORTHAND: it is
    NOT canonical wire and no encoder emits it. It is kept because this host's
    own fixtures have authored the slot that way since it landed, and refusing
    it would break them without moving a single byte of anything an encoder
    produces. Stated here rather than left ambiguous — the decision is "lenient
    on the way in, canonical on the way out", the least breaking of the two.
    """
    if isinstance(value, str):
        return value
    return resolve_display_string(value, sources)


# ── Drawing SVG helpers (Phase 525 — ported from F# DrawingSvg) ──────────────


def _draw_num(n: object) -> str:
    """Canonical SVG number form — whole → no decimal (`10`), else the shortest
    round-trip (`1.5`). Matches the F# / TS hosts byte-for-byte."""
    if isinstance(n, bool) or n is None:
        return "0"
    if isinstance(n, int):
        return str(n)
    if isinstance(n, float):
        if not math.isfinite(n):
            return "0"
        if n == math.floor(n) and abs(n) < 1e15:
            return str(int(n))
        return repr(n)
    return "0"


def _draw_escape(s: str) -> str:
    """XML-escape (raw markup rides the innerHTML seam). `&` first."""
    return (
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;").replace("'", "&#39;")
    )


def _draw_points(points: Value) -> str:
    if not isinstance(points, Arr):
        return ""
    return " ".join(
        f"{_draw_num(p.fields.get('x', 0))},{_draw_num(p.fields.get('y', 0))}"
        for p in points.items
        if isinstance(p, Obj)
    )


def _draw_path_d(commands: Value) -> str:
    """The typed `CurveCommand` list → an SVG path `d` string."""
    if not isinstance(commands, Arr):
        return ""

    def pt(cf: dict[str, Value], key: str) -> str:
        p = cf.get(key)
        pf = p.fields if isinstance(p, Obj) else {}
        return f"{_draw_num(pf.get('x', 0))} {_draw_num(pf.get('y', 0))}"

    parts: list[str] = []
    for c in commands.items:
        if not isinstance(c, Obj):
            continue
        cf = c.fields
        if c.tag == "MoveTo":
            parts.append("M" + pt(cf, "to"))
        elif c.tag == "LineTo":
            parts.append("L" + pt(cf, "to"))
        elif c.tag == "CubicTo":
            parts.append("C" + pt(cf, "control1") + " " + pt(cf, "control2") + " " + pt(cf, "to"))
        elif c.tag == "QuadraticTo":
            parts.append("Q" + pt(cf, "control") + " " + pt(cf, "to"))
        elif c.tag == "Close":
            parts.append("Z")
    return " ".join(parts)


# ── Node coercion ───────────────────────────────────────────────────────────
#
# Typed-decoded layout children (Dashboard / Stack / Card) arrive as `Node`s.
# Structurally-decoded layouts (Tabs / SplitPanel / …) keep their children as
# raw `Obj`s (the decoder did not give them a typed schema). `_as_node` accepts
# either, so every layout body renders uniformly.


def _as_node(value: Value) -> Node | None:
    if isinstance(value, Node):
        return value
    if isinstance(value, Obj) and isinstance(value.fields.get("kind"), Obj):
        node_id = value.fields.get("id")
        kind = value.fields["kind"]
        if isinstance(node_id, str) and isinstance(kind, Obj):
            extras: dict[str, Value] = {
                k: value.fields[k] for k in ("state", "style", "accessibility") if k in value.fields
            }
            return Node(node_id, kind, extras)
    return None


def _child_nodes(fields: dict[str, Value], key: str = "children") -> list[Node]:
    raw = fields.get(key)
    if not isinstance(raw, Arr):
        return []
    return [n for item in raw.items if (n := _as_node(item)) is not None]


# ── Fragment registry (mirrors the F# `collectFragments`) ───────────────────


def _collect_fragments(node: Node, acc: dict[str, Node]) -> None:
    kind = node.kind
    if kind.tag == "FragmentDecl":
        name = kind.fields.get("name")
        body = _as_node(kind.fields.get("body"))
        if isinstance(name, str) and body is not None:
            acc[name] = body
    for child in _child_nodes(kind.fields):
        _collect_fragments(child, acc)
    boundary_child = _as_node(kind.fields.get("child"))
    if boundary_child is not None:
        _collect_fragments(boundary_child, acc)
    if kind.tag == "Switch":
        cases = kind.fields.get("cases")
        if isinstance(cases, Arr):
            for case in cases.items:
                if isinstance(case, Obj):
                    case_child = _as_node(case.fields.get("child"))
                    if case_child is not None:
                        _collect_fragments(case_child, acc)
        switch_default = _as_node(kind.fields.get("default"))
        if switch_default is not None:
            _collect_fragments(switch_default, acc)


class Renderer:
    """Holds the per-render context: host binding sources, the fragment registry,
    and the ambient destination policy.

    ``egress_policy`` is the one place a render's destination posture lives, and
    it is a CONTEXT field rather than a parameter on the emission helpers for the
    reason the seam exists at all: a guarantee that holds only where a call site
    remembered to ask is not a guarantee. Every ``href`` / ``src`` this renderer
    emits consults it, with no caller opt-in anywhere on the path.

    **The default is** :data:`~fuaran_ui.renderer.egress.DENY_NON_LOCAL_EGRESS`
    **at every entry point**, on the decoded-tree argument: an emission cannot
    declare its own egress, so absent a host's declaration it gets none.
    :data:`~fuaran_ui.renderer.egress.PERMISSIVE_EGRESS` is reached BY NAME, so a
    grep for ``PERMISSIVE_EGRESS`` finds every host that has opted back out — the
    permissive choice is visible in the host's own source instead of inherited
    silently.

    Two consequences a host meets on adoption, both deliberate. A ``mailto:`` /
    ``tel:`` href is REFUSED under the default (``allow_non_network=False``):
    those are egress channels with no host for a rule to name, so they can only be
    permitted wholesale, and permitting them by omission is the failure this
    default exists to prevent. And same-origin destinations are ALLOWED
    (``allow_local=True``), so ordinary in-app links and assets render unchanged —
    the default denies leaving, not linking.

    A refused destination RENDERS as a refusal
    (:data:`~fuaran_ui.renderer.egress.EGRESS_REFUSAL_URL` plus the
    :data:`~fuaran_ui.renderer.egress.EGRESS_REFUSAL_ATTRIBUTE` marker), never as
    a silent neuter: "nothing happened" and "this was refused" are different
    facts, and only one of them is debuggable.
    """

    def __init__(
        self,
        sources: BindingSourcesLike | None,
        fragments: dict[str, Node],
        egress_policy: EgressPolicy = DENY_NON_LOCAL_EGRESS,
    ) -> None:
        self.sources = sources
        self.fragments = fragments
        self.egress_policy = egress_policy

    # ── text / value helpers ────────────────────────────────────────────────

    def _text(self, ts: Value) -> str:
        return render_text(ts, self.sources)

    def _state_loading(self, node: Node) -> Node | None:
        state = node.extras.get("state")
        if isinstance(state, Obj):
            return _as_node(state.fields.get("onLoading"))
        return None

    # ── accessibility projection (best-effort over the structural section) ───
    #
    # WHERE the projection lands is a separate question from what it contains,
    # and `_SEMANTIC_ELEMENT_TAGS` (below the class) is the answer: a kind whose
    # body IS the node's semantic element carries it there instead of on the
    # wrapper `<div>`.
    #
    # WHAT it contains is six slots, in the order every reference host emits
    # them: label, labelledby, describedby, role, live, hidden. The projection is
    # meant to be one function ported to every host, so a slot missing here is a
    # silent per-host divergence in the emitted DOM — which is what `hidden` was
    # until it was added.

    def _a11y_attrs(self, node: Node) -> list[tuple[str, str]]:
        a11y = node.extras.get("accessibility")
        if not isinstance(a11y, Obj):
            return []
        out: list[tuple[str, str]] = []
        # ``label`` is a ``Binding[str]`` on the wire (WIRE_FORMAT §3.1;
        # ``schema.json`` maps ``Accessibility.label`` to ``$ref: Binding``), so
        # the canonical form is ``{"$type":"Static","value":"Home"}`` and it
        # resolves through the host sources exactly as the F#/TS/Rust
        # projections do. The non-empty filter is theirs too: an empty
        # accessible name is worse than none, because it silences the content
        # that would otherwise have named the node.
        label = _a11y_name(a11y.fields.get("label"), self.sources)
        if label:
            out.append(("aria-label", label))
        labelled_by = a11y.fields.get("labelledBy")
        if isinstance(labelled_by, str):
            out.append(("aria-labelledby", labelled_by))
        described_by = a11y.fields.get("describedBy")
        if isinstance(described_by, str):
            out.append(("aria-describedby", described_by))
        # `role` is an OPEN vocabulary — the named ARIA roles and the custom
        # escape both travel as the raw string, so a host cannot tell them apart
        # and the reference tiers all emit what they were given. Case-folding it
        # here would rewrite a custom role the author cased deliberately; the
        # named vocabulary is lower-case already, so folding bought nothing and
        # cost fidelity.
        role = a11y.fields.get("role")
        if isinstance(role, str):
            out.append(("role", role))
        # `liveRegion` is the opposite case — a CLOSED lower-case vocabulary
        # (polite | assertive | off) a typed host rejects at decode. Folding it
        # is a no-op for every valid tree and keeps this structural renderer from
        # emitting an invalid `aria-live` for a tree a typed host would refuse,
        # so it stays.
        live = a11y.fields.get("liveRegion")
        if isinstance(live, str):
            out.append(("aria-live", live.lower()))
        # `hidden` is a ``Binding[bool]``: emit ``aria-hidden="true"`` only when
        # it resolves TRUE. False and unresolved both emit NOTHING —
        # ``aria-hidden`` is not a tri-state, and emitting "false" on an
        # unresolved binding would be a claim the tree never made.
        #
        # fuaran#1535 — through the SCALAR resolver. ``resolve_binding``'s
        # ``Transform`` arm is row-shaped, so a pipeline yielding the 1x1 bool
        # cell an author obviously meant here ("hide it when the grid is empty")
        # could never resolve. ``resolve_scalar_bool`` reads the lone cell
        # through the same seam every other scalar slot uses, and every other
        # binding case resolves exactly as before.
        if resolve_scalar_bool(a11y.fields.get("hidden"), self.sources) is True:
            out.append(("aria-hidden", "true"))
        return out

    # ── the node wrapper ─────────────────────────────────────────────────────

    def render_node(self, node: Node) -> str:
        # fuaran#1535 — CONDITIONAL PRESENCE, before anything else is computed. A
        # resolved ``False`` on the envelope's ``visible`` predicate emits
        # NOTHING: no element, no placeholder, no ``aria-hidden``, nothing in the
        # layout and nothing in the accessibility tree. An absent, unresolved or
        # errored predicate RENDERS — a missing source silently hiding content is
        # the one failure a reader cannot see, cannot report and cannot work
        # around.
        #
        # The guard sits on this one method rather than at every call site that
        # produces a child, so a kind added tomorrow inherits it without anyone
        # remembering to.
        if not is_node_visible(node.extras.get("visible"), self.sources):
            return ""
        class_name = node_class_name(node)

        # fuaran#1112 — the node-level tooltip trait. An EMPTY resolved hint emits
        # nothing at all: a declared hint that says nothing is markup that reveals
        # an empty box on hover, and the wrapper class / focus stop / describedby
        # would then advertise a description that is not there. The renderer
        # simply does not draw it — the validator is where the declaration is
        # reported. Parity-locked with both reference renderers.
        raw_tooltip = node.extras.get("tooltip")
        tooltip_text: str | None = None
        if raw_tooltip is not None:
            resolved = self._text(raw_tooltip)
            if resolved.strip() != "":
                tooltip_text = resolved
        if tooltip_text is not None:
            class_name += " fuaran-has-tooltip"

        attrs: list[tuple[str, str]] = [
            ("id", node.id),
            ("data-fuaran-node-id", node.id),
            ("class", class_name),
        ]
        # fuaran#1472 / fuaran#1696 — the DECLARED direction rides the wrapper,
        # first among the attributes that follow `class`, which is where the
        # reference host and `fuaran-rs` put it. It is the other half of §3.1:
        # the class above isolates the run, this states which way it reads. A
        # host that emitted neither passed every codec fixture for the member
        # while rendering an RTL document left-to-right, which is why the
        # obligation is declared in the corpus roster rather than left as prose.
        style_extra = node.extras.get("style")
        attrs.extend(text_direction_attrs(style_extra if isinstance(style_extra, Obj) else None))
        # Route the projection: a kind whose body IS the node's semantic element
        # takes the a11y attributes onto that element; every other kind carries
        # them on the wrapper, as before. The wrapper keeps the node's address
        # (`data-fuaran-node-id`) either way.
        semantic_attrs: list[tuple[str, str]] = []
        wrapper_attrs: list[tuple[str, str]] = []
        if node.kind.tag in _SEMANTIC_ELEMENT_TAGS:
            semantic_attrs = self._a11y_attrs(node)
        else:
            wrapper_attrs = self._a11y_attrs(node)

        # fuaran#1112 — route the hint's description and, where the wrapper is the
        # described element, its focus stop. The two travel together by
        # construction: see `_tooltip_rides_semantic_element`.
        if tooltip_text is not None:
            hint_id = _tooltip_hint_id(node.id)
            if _tooltip_rides_semantic_element(node.kind.tag):
                semantic_attrs = _with_tooltip_described_by(hint_id, semantic_attrs)
            else:
                wrapper_attrs = _with_tooltip_described_by(hint_id, wrapper_attrs)
                wrapper_attrs.append(("tabindex", "0"))

        attrs.extend(wrapper_attrs)
        body = self.render_kind(node, semantic_attrs)

        # The hint element itself — a sibling of the body INSIDE the wrapper,
        # which is what makes it hoverable: the pointer moving from the node onto
        # the hint never leaves the wrapper, so the `:hover` that revealed it
        # still holds (WCAG 1.4.13). Placed after the body so the reading order is
        # thing-then-description.
        hint = (
            ""
            if tooltip_text is None
            else text_element(
                "span",
                [("id", _tooltip_hint_id(node.id)), ("class", "fuaran-tooltip"), ("role", "tooltip")],
                tooltip_text,
            )
        )
        return element("div", attrs, body + hint)

    # ── kind dispatch ─────────────────────────────────────────────────────────

    def render_kind(self, node: Node, semantic_attrs: Sequence[tuple[str, str]] = ()) -> str:
        kind = node.kind
        tag = kind.tag
        fields = kind.fields
        handler = _DISPATCH.get(tag or "")
        if handler is not None:
            # The three semantic-element kinds take the routed projection as a
            # fourth argument; every other handler keeps the uniform signature.
            if tag in _SEMANTIC_ELEMENT_TAGS:
                return handler(self, node, fields, semantic_attrs)  # type: ignore[call-arg]
            return handler(self, node, fields)
        # Recognised-but-unhandled kind: render any children so the subtree is
        # never silently dropped (the wrapper already carries the kind class).
        children = _child_nodes(fields)
        return "".join(self.render_node(c) for c in children)

    # ── layouts ──────────────────────────────────────────────────────────────

    def _children_html(self, fields: dict[str, Value]) -> str:
        return "".join(self.render_node(c) for c in _child_nodes(fields))

    def _box(self, node: Node, fields: dict[str, Value]) -> str:
        # Phase 390 — the unified container. Role + layout mode drive the emitted
        # element + classes so each retired kind's HTML/a11y is byte-identical:
        # Card role → <section class="fuaran-layout-card">; Dashboard role (or
        # Group+Auto) → <div class="fuaran-layout-dashboard">; Group+Grid → grid
        # div; Group+Flex → stack div; Separator → <hr> (reserved).
        role = fields.get("role")
        layout = fields.get("layout")
        layout_obj = layout if isinstance(layout, Obj) else None
        layout_mode = layout_obj.tag if layout_obj is not None else None

        if role == "Card":
            heading = fields.get("heading")
            header = (
                text_element("header", [("class", "fuaran-card-heading")], self._text(heading))
                if heading is not None
                else ""
            )
            body = element("div", [("class", "fuaran-card-body")], self._children_html(fields))
            return element("section", [("class", "fuaran-layout-card")], header + body)
        if role == "Dashboard" or (role == "Group" and layout_mode == "Auto"):
            return element("div", [("class", "fuaran-layout-dashboard")], self._children_html(fields))
        if role == "Separator":
            return element("hr", [("class", "fuaran-layout-separator")], "")
        if role == "Group" and layout_mode == "Grid":
            lf = layout_obj.fields if layout_obj is not None else {}
            template = lf.get("templateColumns")
            if not isinstance(template, str):
                cols = lf.get("cols")
                cols = cols if isinstance(cols, int) else 1
                template = f"repeat({cols}, 1fr)"
            # `templateColumns` is a free string on the wire that lands verbatim
            # in a `style` attribute — the one slot in this renderer where a
            # decoded document writes CSS. Unsanitised, a value carrying
            # `;background:url(https://collector/?d=…)` closed the declaration,
            # opened a second one, and fetched on RENDER with no user act,
            # outside the egress policy that governs every href and src in the
            # same document; the React client dropped the identical value
            # silently. The rule is the shared emission grammar, so every host
            # now emits the same bytes for the same tree.
            template, css_refusal_attrs = sanitize_css_value_for_slot("grid-template-columns", template)
            # `gap` (Phase 459) emits only when set — a gap-free grid stays
            # byte-identical to the pre-459 emission (mirrors F# Render.fs).
            style = f"grid-template-columns:{template}"
            gap = lf.get("gap")
            if isinstance(gap, int):
                style = f"{style};gap:{gap}px"
            return element(
                "div",
                [("class", "fuaran-layout-grid"), ("style", style)] + css_refusal_attrs,
                self._children_html(fields),
            )
        if role == "Group" and layout_mode == "Masonry":
            # WIRE_FORMAT §3.6.7 — column-FILL, realised through the CSS
            # MULTI-COLUMN family (`column-count`, and the `gap` shorthand's
            # `column-gap` half), which the specification makes NORMATIVE.
            # `grid-template-rows: masonry` is the other candidate spelling and
            # must NOT be substituted: it is not deterministically supported
            # across engines, so a document rendered through it would lay out as
            # a masonry for some readers and as an ordinary grid for others, and
            # a layout mode whose result depends on which engine reads it is not
            # a wire contract.
            #
            # The break-avoidance obligation (`.fuaran-layout-masonry > *`) is
            # the reference stylesheet's, exactly as on the F#/TS hosts — the
            # class hook here is what carries it.
            lf = layout_obj.fields if layout_obj is not None else {}
            cols = lf.get("cols")
            cols = cols if isinstance(cols, int) else 1
            style = f"column-count:{cols}"
            gap = lf.get("gap")
            if isinstance(gap, int):
                style = f"{style};gap:{gap}px"
            return element(
                "div",
                [("class", "fuaran-layout-masonry"), ("style", style)],
                self._children_html(fields),
            )
        # Group + Flex (the default / fallthrough).
        lf = layout_obj.fields if layout_obj is not None else {}
        dir_class = "fuaran-stack-horizontal" if lf.get("direction") == "Horizontal" else "fuaran-stack-vertical"
        wrap = " fuaran-stack-wrap" if lf.get("wrap") is True else ""
        # `gap` (Phase 459) emits only when set — a gap-free stack carries no
        # `style` attribute, byte-identical to the pre-459 emission.
        attrs: list[tuple[str, str]] = [("class", f"fuaran-layout-stack {dir_class}{wrap}")]
        gap = lf.get("gap")
        if isinstance(gap, int):
            attrs.append(("style", f"gap:{gap}px"))
        return element("div", attrs, self._children_html(fields))

    def _split_panel(self, node: Node, fields: dict[str, Value]) -> str:
        weight = fields.get("weight")
        left_w = max(0.0, min(1.0, float(weight))) if isinstance(weight, (int, float)) else 0.5
        right_w = 1.0 - left_w
        children = _child_nodes(fields)
        left = children[:1]
        right = children[1:]
        left_html = element(
            "div",
            [("class", "fuaran-split-pane fuaran-split-pane-left"), ("style", f"flex:{left_w:f} 1 0")],
            "".join(self.render_node(c) for c in left),
        )
        right_html = element(
            "div",
            [("class", "fuaran-split-pane fuaran-split-pane-right"), ("style", f"flex:{right_w:f} 1 0")],
            "".join(self.render_node(c) for c in right),
        )
        return element("div", [("class", "fuaran-layout-split-panel")], left_html + right_html)

    def _tab_label(self, child: Node) -> str:
        # A Box with role=Card and a heading names its tab (mirrors F# render).
        if child.kind.tag == "Box" and child.kind.fields.get("role") == "Card":
            heading = child.kind.fields.get("heading")
            if heading is not None:
                return self._text(heading)
        return child.id

    def _tabs(self, node: Node, fields: dict[str, Value]) -> str:
        children = _child_nodes(fields)
        vertical = fields.get("orientation") == "Vertical"
        orientation_class = "fuaran-tabs-vertical" if vertical else "fuaran-tabs-horizontal"
        active = resolve_binding(fields.get("activeIndex"), self.sources)
        active_index = active if isinstance(active, int) else 0
        active_index = max(0, min(active_index, max(0, len(children) - 1)))

        tabs: list[str] = []
        for i, child in enumerate(children):
            is_active = i == active_index
            cls = "fuaran-tab" + (" fuaran-tab-active" if is_active else "")
            tabs.append(
                element(
                    "button",
                    [
                        ("id", f"{node.id}-tab-{i}"),
                        ("class", cls),
                        ("role", "tab"),
                        ("aria-selected", "true" if is_active else "false"),
                        ("aria-controls", f"{node.id}-panel-{i}"),
                        ("data-tab-index", str(i)),
                    ],
                    element("span", [("class", "fuaran-tab-label")], escape_text(self._tab_label(child))),
                )
            )
        bar = element(
            "div",
            [
                ("class", "fuaran-tabs-bar"),
                ("role", "tablist"),
                ("aria-orientation", "vertical" if vertical else "horizontal"),
            ],
            "".join(tabs),
        )
        panel = ""
        if children:
            active_child = children[active_index]
            panel = element(
                "div",
                [
                    ("id", f"{node.id}-panel-{active_index}"),
                    ("role", "tabpanel"),
                    ("aria-labelledby", f"{node.id}-tab-{active_index}"),
                    ("class", "fuaran-tabs-panel"),
                ],
                self.render_node(active_child),
            )
        panels = element("div", [("class", "fuaran-tabs-panels")], panel)
        return element("div", [("class", f"fuaran-layout-tabs {orientation_class}")], bar + panels)

    def _summary_list(self, node: Node, fields: dict[str, Value]) -> str:
        heading = fields.get("heading")
        header = (
            text_element("header", [("class", "fuaran-summary-list-heading")], self._text(heading))
            if heading is not None
            else ""
        )
        body = element("div", [("class", "fuaran-summary-list-body")], self._children_html(fields))
        return element("section", [("class", "fuaran-layout-summary-list")], header + body)

    def _disclosure(self, node: Node, fields: dict[str, Value]) -> str:
        resolved_open = resolve_binding(fields.get("open"), self.sources)
        is_open = resolved_open if isinstance(resolved_open, bool) else (fields.get("defaultOpen") is True)
        attrs: list[tuple[str, str]] = [("class", "fuaran-layout-disclosure")]
        if is_open:
            attrs.append(("open", ""))
        summary = text_element("summary", [("class", "fuaran-disclosure-summary")], self._text(fields.get("heading")))
        body = element("div", [("class", "fuaran-disclosure-body")], self._children_html(fields))
        return element("details", attrs, summary + body)

    def _stepper(self, node: Node, fields: dict[str, Value]) -> str:
        children = _child_nodes(fields)
        active = resolve_binding(fields.get("activeStep"), self.sources)
        active_index = active if isinstance(active, int) else 0
        steps = []
        for i in range(len(children)):
            cls = "fuaran-stepper-step" + (" fuaran-stepper-step-active" if i == active_index else "")
            steps.append(element("li", [("class", cls), ("data-step-index", str(i))], escape_text(str(i + 1))))
        numbers = element("ol", [("class", "fuaran-stepper-numbers")], "".join(steps))
        body_child = children[active_index] if 0 <= active_index < len(children) else None
        body = element(
            "div",
            [("class", "fuaran-stepper-body")],
            self.render_node(body_child) if body_child is not None else "",
        )
        return element("div", [("class", "fuaran-layout-stepper")], numbers + body)

    def _modal(self, node: Node, fields: dict[str, Value]) -> str:
        """The overlay's two MODALITIES, which are two class families and not one.

        Overlay render-fidelity contract (server half): the surface is ALWAYS
        emitted (no portal, ever, in either modality), positioned by CSS; closed
        is the ``hidden`` attribute rather than omission.

        **The two modalities do not share markup, and reading them as one shape
        with a modifier class is the mistake this host made** (Phase 1654; found
        by making the class-vocabulary parity oracle non-vacuous, which is how a
        divergence in a family the stylesheet already styles had gone unseen).

        - A **blocking modal** is a scrim (``fuaran-modal-overlay``) wrapping a
          dialog (``fuaran-modal-dialog``), which claims ``aria-modal="true"``.
        - A **popover** carries the ``fuaran-popover`` family and **no scrim
          element at all** — the page behind it is genuinely still available, so
          there is nothing to cover, and the anchor declaration rides the OUTER
          element as ``data-fuaran-popover-anchor``, recording that the id was
          read. It carries the dialog role WITHOUT ``aria-modal``: that is the
          INERTNESS claim, and emitting it here tells assistive technology the
          rest of the page is unreachable when it is not (fuaran#1119).

        The class names are the reference host's, exactly, because the byte-copied
        reference stylesheet styles those and nothing else — a popover under the
        modal family renders unstyled and a ``fuaran-popover-overlay`` scrim is a
        class no stylesheet in the estate has a rule for.
        """
        is_open = resolve_binding(fields.get("open"), self.sources) is True
        popover = fields.get("modality") == "Popover"
        prefix = "fuaran-popover" if popover else "fuaran-modal"

        parts: list[str] = []
        heading = fields.get("heading")
        if heading is not None:
            parts.append(text_element("h2", [("class", f"{prefix}-heading")], self._text(heading)))
        if fields.get("dismissable") is True:
            parts.append(
                text_element(
                    "button",
                    [("class", f"{prefix}-dismiss"), ("type", "button"), ("aria-label", "Close")],
                    "×",
                )
            )
        parts.append(element("div", [("class", f"{prefix}-body")], self._children_html(fields)))

        surface_attrs: list[tuple[str, str]] = [
            ("class", "fuaran-popover-surface" if popover else "fuaran-modal-dialog"),
            ("role", "dialog"),
        ]
        if not popover:
            surface_attrs.append(("aria-modal", "true"))
        surface = element("div", surface_attrs, "".join(parts))

        outer_attrs: list[tuple[str, str]] = [("class", "fuaran-popover" if popover else "fuaran-modal-overlay")]
        if not is_open:
            outer_attrs.append(("hidden", ""))
        anchor = fields.get("anchor")
        if popover and isinstance(anchor, str):
            outer_attrs.append(("data-fuaran-popover-anchor", anchor))
        return element("div", outer_attrs, surface)

    def _scroll_area(self, node: Node, fields: dict[str, Value]) -> str:
        axis = {"Horizontal": "horizontal", "Both": "both"}.get(str(fields.get("orientation")), "vertical")
        attrs: list[tuple[str, str]] = [
            ("class", f"fuaran-scrollarea fuaran-scrollarea-{axis}"),
            ("tabindex", "0"),
        ]
        style_parts: list[str] = []
        max_height = fields.get("maxHeight")
        if isinstance(max_height, int):
            style_parts.append(f"max-height:{max_height}px")
        max_width = fields.get("maxWidth")
        if isinstance(max_width, int):
            style_parts.append(f"max-width:{max_width}px")
        if style_parts:
            attrs.append(("style", ";".join(style_parts)))
        return element("div", attrs, self._children_html(fields))

    # ── displays ─────────────────────────────────────────────────────────────

    def _heading(self, node: Node, fields: dict[str, Value]) -> str:
        variant = fields.get("variant")
        suffix = {
            "Eyebrow": " fuaran-heading-eyebrow",
            "Caption": " fuaran-heading-caption",
            "Lead": " fuaran-heading-lead",
        }.get(str(variant), "")
        level = fields.get("level")
        level = level if isinstance(level, int) and 1 <= level <= 6 else 6
        return text_element(f"h{level}", [("class", f"fuaran-heading{suffix}")], self._text(fields.get("text")))

    def _markdown(self, node: Node, fields: dict[str, Value]) -> str:
        # The POLICY-TAKING markdown entry, never the pure `to_html`: a markdown
        # body is the densest destination surface a tree carries (every link and
        # every inline image), and the pure form is the permissive case by
        # definition. `to_html` stays published for a host rendering markdown it
        # authored itself; a DECODED tree reaching it would be the ambient
        # guarantee's one blind spot.
        html = markdown.to_html_with_egress(self.egress_policy, self._text(fields.get("text")))
        return element("div", [("class", "fuaran-markdown")], html)

    def _metric(self, node: Node, fields: dict[str, Value]) -> str:
        # 0.2.0 rename law — the scalar displayed value is `value`. Phase 648 —
        # the value/trend are scalar slots: a `Transform` resolves to its 1×1
        # result cell (the same dispatch as the client renderer).
        value = resolve_scalar_number(fields.get("value"), self.sources)
        if value is None:
            loading = self._state_loading(node)
            if loading is not None:
                return self.render_node(loading)
        tone = str(fields.get("tone", "Default")).lower()
        value_text = metric_value_text(fields, value)
        parts = [
            text_element("div", [("class", "fuaran-metric-label")], self._text(fields.get("label"))),
            text_element("div", [("class", "fuaran-metric-value")], value_text),
        ]
        # Phase 648 — the trend div (the client emits it; the server used to omit
        # it). A resolved trend formats through `trendFormat`; an unresolved one
        # renders empty, matching the F#/TS hosts.
        trend_binding = fields.get("trend")
        if trend_binding is not None:
            trend = resolve_scalar_number(trend_binding, self.sources)
            if trend is None:
                # Unresolved: the bare div, byte-for-byte as before. There is no
                # sentiment to state, and inventing `unchanged` would be a claim.
                parts.append(text_element("div", [("class", "fuaran-metric-trend")], ""))
            else:
                # fuaran#867 — the trend element carries a SENTIMENT, not an
                # unconditional success class. Mirrors the reference server
                # renderer byte-for-byte; `tone` still colours the tile alone and
                # is neither read from nor written to here.
                sentiment, glyph = trend_sentiment(fields.get("trendPolarity"), trend)
                parts.append(
                    element(
                        "div",
                        [("class", f"fuaran-metric-trend fuaran-metric-trend-{sentiment}")],
                        text_element(
                            "span",
                            [
                                ("class", "fuaran-metric-trend-glyph"),
                                ("role", "img"),
                                ("aria-label", sentiment),
                            ],
                            glyph,
                        )
                        + escape_text(format_number(fields.get("trendFormat"), trend)),
                    )
                )
        subtext = fields.get("subtext")
        if subtext is not None:
            parts.append(text_element("div", [("class", "fuaran-metric-subtext")], self._text(subtext)))
        return element("div", [("class", f"fuaran-metric fuaran-metric-{tone}")], "".join(parts))

    def _badge(self, node: Node, fields: dict[str, Value]) -> str:
        variant = str(fields.get("variant", "Neutral")).lower()
        return text_element(
            "span", [("class", f"fuaran-badge fuaran-badge-{variant}")], self._text(fields.get("label"))
        )

    def _callout(self, node: Node, fields: dict[str, Value]) -> str:
        tone = str(fields.get("tone", "Default")).lower()
        parts = []
        heading = fields.get("heading")
        if heading is not None:
            parts.append(text_element("div", [("class", "fuaran-callout-heading")], self._text(heading)))
        parts.append(text_element("div", [("class", "fuaran-callout-body")], self._text(fields.get("body"))))
        return element("div", [("class", f"fuaran-callout fuaran-callout-{tone}")], "".join(parts))

    def _progress(self, node: Node, fields: dict[str, Value]) -> str:
        resolved = resolve_binding(fields.get("fraction"), self.sources)
        if resolved is None:
            loading = self._state_loading(node)
            if loading is not None:
                return self.render_node(loading)
        fraction = float(resolved) if isinstance(resolved, (int, float)) else 0.0
        tone = str(fields.get("tone", "Default")).lower()
        indeterminate = " fuaran-progress-indeterminate" if fields.get("indeterminate") is True else ""
        parts = []
        label = fields.get("label")
        if label is not None:
            parts.append(text_element("div", [("class", "fuaran-progress-label")], self._text(label)))
        fill = element(
            "div",
            [("class", "fuaran-progress-fill"), ("style", f"width:{fraction * 100.0:f}%")],
            "",
        )
        parts.append(element("div", [("class", "fuaran-progress-bar")], fill))
        return element("div", [("class", f"fuaran-progress fuaran-progress-{tone}{indeterminate}")], "".join(parts))

    def _skeleton(self, node: Node, fields: dict[str, Value]) -> str:
        rows = fields.get("rows")
        rows = rows if isinstance(rows, int) and rows > 0 else 1
        body = "".join(element("div", [("class", "fuaran-skeleton-row")], "") for _ in range(rows))
        return element("div", [("class", "fuaran-skeleton")], body)

    def _icon(self, node: Node, fields: dict[str, Value]) -> str:
        # Phase 821 — the standalone icon-only display kind. The glyph NAME
        # rides `data-icon` (the uniform icon-hook contract — no text content,
        # hosts map it to glyphs); size + tone are modifier classes. A11y:
        # decorative (no label) emits `aria-hidden="true"`; labelled emits
        # `role="img"` + `aria-label`. Mirrors the F# SSR renderer byte-for-byte.
        size = str(fields.get("size", "Medium")).lower()
        tone = str(fields.get("tone", "Default")).lower()
        icon = fields.get("icon")
        attrs: list[tuple[str, str]] = [
            ("class", f"fuaran-icon fuaran-icon--{size} fuaran-icon-{tone}"),
            ("data-icon", icon if isinstance(icon, str) else ""),
        ]
        label = fields.get("label")
        if isinstance(label, str):
            attrs.append(("role", "img"))
            attrs.append(("aria-label", label))
        else:
            attrs.append(("aria-hidden", "true"))
        return element("span", attrs, "")

    def _sparkline(self, node: Node, fields: dict[str, Value]) -> str:
        # Phase 1099 — the em-dash placeholder is retired for a RESOLVED series.
        # This host drew nothing at all before: two lines that emitted an em-dash
        # and never read `source`. It now lowers the series through the shared
        # `Sparkline` geometry builder and renders it with the SAME
        # `_drawing_svg` the `Drawing` arm uses, so the picture is the corpus's
        # rather than this host's, byte for byte.
        #
        # The `fuaran-sparkline` class stays on the CONTAINER — that is where the
        # sizing and the inherited `color` the `currentColor` stroke inks from
        # live, so the render-fidelity hook survives the change.
        #
        # The em-dash branch survives for the UNRESOLVED or EMPTY series only: a
        # readable, deterministic stand-in rather than a blank, exactly as
        # before. This is a deliberate SSR BEHAVIOUR change and the README's
        # lowering-coverage section moves with it.
        from ..charts import try_lower_sparkline_node

        series = _float_series(resolve_binding(fields.get("source"), self.sources))
        drawing = try_lower_sparkline_node(node.id, series) if series is not None else None
        if drawing is not None and isinstance(drawing.kind, Obj):
            return element("div", [("class", "fuaran-sparkline")], self._drawing_svg(drawing.kind.fields))
        return text_element("div", [("class", "fuaran-sparkline fuaran-sparkline-empty")], _EM_DASH)

    def _label_value_row(self, node: Node, fields: dict[str, Value]) -> str:
        # Phase 648 — a scalar slot: a `Transform` resolves to its 1×1 result
        # cell (ambiguity stays loud), matching the client's value projection.
        value = resolve_scalar_number(fields.get("value"), self.sources)
        if value is None:
            loading = self._state_loading(node)
            if loading is not None:
                return self.render_node(loading)
        emphasis = " fuaran-label-value-row-emphasis" if fields.get("emphasis") is True else ""
        # 0.2.0 rename law — the scalar displayed value is `value`.
        value_text = format_number(fields.get("format"), value) if value is not None else _EM_DASH
        label = text_element("span", [("class", "fuaran-label-value-row-label")], self._text(fields.get("label")))
        val = text_element("span", [("class", "fuaran-label-value-row-value")], value_text)
        return element("div", [("class", f"fuaran-label-value-row{emphasis}")], label + val)

    def _fact(self, node: Node, fields: dict[str, Value]) -> str:
        # A labeled TEXT fact tile — Metric's chrome for a `TextSource` value.
        # `render_text` resolves Literal / Bound / I18n identically on both
        # surfaces, so a `Bound` `Selection` shows its `defaultValue` (Phase 629)
        # and a `Bound` `Transform` its 1×1 result cell (Phase 632/648).
        tone = str(fields.get("tone", "Default")).lower()
        emphasis = " fuaran-fact-emphasis" if fields.get("emphasis") is True else ""
        icon = fields.get("icon")
        icon_html = text_element("span", [("class", "fuaran-fact-icon")], icon) if isinstance(icon, str) else ""
        value_html = icon_html + text_element("span", [], self._text(fields.get("value")))
        parts = [
            text_element("div", [("class", "fuaran-fact-label")], self._text(fields.get("label"))),
            element("div", [("class", "fuaran-fact-value")], value_html),
        ]
        help_text = fields.get("help")
        if help_text is not None:
            parts.append(text_element("div", [("class", "fuaran-fact-help")], self._text(help_text)))
        return element("div", [("class", f"fuaran-fact fuaran-fact-{tone}{emphasis}")], "".join(parts))

    def _link(self, node: Node, fields: dict[str, Value], semantic_attrs: Sequence[tuple[str, str]] = ()) -> str:
        # The scheme floor answers whether this URL is safe to HAVE; the ambient
        # policy decides whether this tree may point at that host AT ALL. A
        # refused href renders as `about:blank#fuaran-egress-refused` carrying the
        # class + host, so the refusal is visible in the document rather than only
        # in the logs.
        #
        # `DOWNLOAD` is deliberately NOT the class here even when `download` is
        # set: the class names the SINK the browser reaches, and a `download`
        # anchor is still a hyperlink the user must act on. Scoping it separately
        # would let a policy that denied hyperlinks admit the same destination by
        # flipping one boolean on the tree.
        href_value = resolve_binding(fields.get("href"), self.sources)
        href, egress_attrs = sanitize_url_for_egress(
            self.egress_policy, EgressClass.HYPERLINK, href_value if isinstance(href_value, str) else ""
        )
        attrs: list[tuple[str, str]] = [("class", "fuaran-link"), ("href", href)]
        # `rel` and `target` were emitted VERBATIM, so a decoded tree could write
        # `rel="opener"` on a `_blank` link and re-enable `window.opener`, or
        # name an arbitrary browsing context in `target`. Both are closed token
        # sets now, resolved TOGETHER because the `rel` rule depends on the
        # sanitised target: `noopener noreferrer` is FORCED on `_blank` whether
        # or not the document asked. Same grammar, same order, same bytes as
        # every other host.
        rel_value = fields.get("rel")
        target_value = fields.get("target")
        safe_target, safe_rel = sanitize_link_anchor(
            target_value if isinstance(target_value, str) else None,
            rel_value if isinstance(rel_value, str) else None,
        )
        if safe_rel is not None:
            attrs.append(("rel", safe_rel))
        if safe_target is not None:
            attrs.append(("target", safe_target))
        if fields.get("download") is True:
            attrs.append(("download", ""))
        # The node's a11y projection lands on the anchor.
        attrs.extend(semantic_attrs)
        # The refusal marker rides the element that carries the refused href, so a
        # reader of the DOM sees WHY this anchor points at `about:blank`. Empty on
        # an allow, and emitted LAST so an adopting host's diff against the
        # pre-policy bytes is a pure suffix.
        attrs.extend(egress_attrs)
        return text_element("a", attrs, self._text(fields.get("label")))

    def _image(self, node: Node, fields: dict[str, Value], semantic_attrs: Sequence[tuple[str, str]] = ()) -> str:
        # `src` is the MEDIA class, and it is the one that matters most: the
        # browser fetches it with NO user act, so RENDERING the tree IS the
        # request. `https://collector.example/?s=<bound state>` passes every
        # scheme check — allowlisted scheme, well-formed host, no script anywhere
        # — and exfiltrates on sight. Only the origin allowlist closes it, which
        # is why the ambient default denies rather than waiting to be asked.
        src_value = resolve_binding(fields.get("src"), self.sources)
        src, egress_attrs = sanitize_url_for_egress(
            self.egress_policy, EgressClass.MEDIA, src_value if isinstance(src_value, str) else ""
        )
        variant = fields.get("variant")
        cls = {
            "Avatar": "fuaran-image fuaran-image-avatar",
            "Rounded": "fuaran-image fuaran-image-rounded",
        }.get(str(variant), "fuaran-image")
        # fuaran#1077 — the presentation tokens map to CLASSES and nothing else:
        # no value from the tree ever reaches a style attribute. `Natural` emits
        # NO class on either axis, so a pre-phase tree's class attribute is
        # byte-identical to what it was.
        cls += _IMAGE_FIT_CLASS.get(str(fields.get("fit")), "")
        cls += _IMAGE_ASPECT_CLASS.get(str(fields.get("aspectRatio")), "")
        # fuaran#1080 — the responsive candidate list. Three properties, each
        # load-bearing:
        #
        # SANITISED PER ENTRY, at the same MEDIA class the primary `src` uses. A
        # candidate is a URL the browser fetches with no user act — exactly what
        # the floor exists for — so routing only the primary through it would make
        # this slot a documented way around the one rule this node has.
        #
        # A FAILING ENTRY IS DROPPED, not neutered. The `<img>`'s `src` must
        # exist, so it collapses to the refusal URL; a candidate has no such
        # obligation, and offering the browser a rendition guaranteed to fail is
        # worse than offering it one fewer. The primary `src` stays the fallback
        # the whole mechanism rests on.
        #
        # ASCENDING BY WIDTH, sorted HERE. The wire preserves authored array order
        # (§3.6.4), so canonical output is the RENDERER's obligation, not the
        # codec's — and `sorted` is stable, so two entries at one width keep their
        # authored order rather than swapping on a re-render.
        srcset_attrs: list[tuple[str, str]] = []
        raw_srcset = fields.get("srcSet")
        if isinstance(raw_srcset, Arr):
            candidates: list[str] = []
            for entry in sorted(
                (e for e in raw_srcset.items if isinstance(e, Obj)),
                key=lambda e: e.fields.get("width", 0),  # type: ignore[arg-type,return-value]
            ):
                resolved = resolve_binding(entry.fields.get("src"), self.sources)
                safe, refusal = sanitize_url_for_egress(
                    self.egress_policy, EgressClass.MEDIA, resolved if isinstance(resolved, str) else ""
                )
                # The refusal is read from the seam's own marker list, never by
                # string-comparing the URL it substitutes, so a later change to
                # that substitute cannot silently turn a dropped candidate into a
                # served one.
                if safe == "" or refusal:
                    continue
                candidates.append(f"{safe} {entry.fields.get('width')}w")
            if candidates:
                # `sizes` is BOUNDED, and `100vw` is the only value the tree can
                # justify: nothing in the document says how wide this element will
                # be laid out, and the language has no media-query slot for an
                # author to say so.
                srcset_attrs = [("srcset", ", ".join(candidates)), ("sizes", "100vw")]
        # fuaran#1077 — `Eager` emits no attribute at all (the browser's own
        # default); only `Lazy` is a positive declaration. Deferring an
        # above-the-fold image is a regression, which is why the default is not
        # the "optimised" value and a host MUST NOT infer laziness from position.
        loading_attrs: list[tuple[str, str]] = [("loading", "lazy")] if fields.get("loading") == "Lazy" else []
        # The a11y projection lands on the `<img>` itself; the refusal marker last.
        img = void_element(
            "img",
            [
                ("class", cls),
                ("src", src),
                ("alt", self._text(fields.get("alt"))),
                *srcset_attrs,
                *loading_attrs,
                *semantic_attrs,
                *egress_attrs,
            ],
        )
        # fuaran#1079 — the expansion affordance. The BASELINE IS A REAL LINK, not
        # a marked-up control waiting for script: `<a href="{the sanitised src}">`
        # around the `<img>` means a reader with no JavaScript — a crawler, a text
        # browser, a locked-down client, a hydration that failed — clicks the
        # thumbnail and gets the full-size asset in the browser's own viewer.
        # `data-fuaran-expandable` is VALUELESS (the slot is a bool whose `false`
        # is the absence of the attribute) and is a marker ON a working link,
        # never the mechanism.
        #
        # A REFUSED `src` EMITS NO ANCHOR — §3.6.4's dropped-candidate rule turned
        # on the affordance. A link to the refusal URL is exactly the dead control
        # this design exists to avoid; the image still renders with its refusal
        # marker, and the reader is simply not offered an expansion that could not
        # work.
        #
        # NOTHING CROSSES THE DISPATCH GATE: no `Action`, no handler, no onclick.
        # The wire says the asset is reachable, the anchor makes it reachable, and
        # where the picture opens is a rendering choice.
        if fields.get("expandable") is True and src != "" and not egress_attrs:
            img = element(
                "a",
                [("class", "fuaran-image-expand"), ("href", src), ("data-fuaran-expandable", "")],
                img,
            )
        # fuaran#1078 — the caption. ABSENT returns the emission UNTOUCHED, which
        # is the acceptance criterion expressed as control flow rather than as a
        # claim: there is no wrapper to be byte-identical to, because there is no
        # wrapper. Present, it is the semantic BINDING an ad-hoc sibling text node
        # could never state — assistive technology announces the two together
        # instead of reading the caption as the next paragraph. Nothing moves onto
        # the `<figure>`: the a11y projection, the egress marker and the sanitised
        # `src` all stay on the element they describe.
        #
        # The NESTING is `figure > a > img`, with the `<figcaption>` as the
        # ANCHOR'S SIBLING — the caption is deliberately OUTSIDE the link target.
        # It is prose a reader selects, quotes and reads, not a second click
        # surface, and putting interactive content inside the element whose job is
        # to LABEL the image inverts what `<figure>`/`<figcaption>` expresses.
        caption = fields.get("caption")
        if caption is None:
            return img
        return element(
            "figure",
            [("class", "fuaran-image-figure")],
            img + text_element("figcaption", [("class", "fuaran-image-figure-caption")], self._text(caption)),
        )

    #: fuaran#1111 — the wire permission → sandbox-token map, in DECLARATION
    #: order. `AllowFullscreen` is deliberately absent: fullscreen is a
    #: permissions-policy directive and rides `allow`, not `sandbox`, and
    #: emitting it as a sandbox token would grant nothing while looking like it
    #: granted something.
    _SANDBOX_TOKENS = (
        ("AllowScripts", "allow-scripts"),
        ("AllowSameOrigin", "allow-same-origin"),
        ("AllowForms", "allow-forms"),
    )

    #: fuaran#1111 — the reserved-box classes. `Natural` emits none, so an embed
    #: that declares no ratio is byte-identical to what it would have been.
    _EMBED_ASPECT_CLASS = {
        "Square": " fuaran-embed-aspect-square",
        "FourThree": " fuaran-embed-aspect-four-three",
        "ThreeTwo": " fuaran-embed-aspect-three-two",
        "SixteenNine": " fuaran-embed-aspect-sixteen-nine",
    }

    def _embed(self, node: Node, fields: dict[str, Value], semantic_attrs: Sequence[tuple[str, str]] = ()) -> str:
        """fuaran#1111 — the sandboxed third-party browsing context.

        Four contract points, and each is a claim the bytes cannot carry:

        * The ACCESSIBLE NAME is emitted ALWAYS, the empty string included. A
          frame is a focus container a reader tabs INTO, so it is never
          decorative, and an unnamed one is announced as "frame" and nothing more.
        * `sandbox` is emitted ALWAYS and EMPTY when nothing is granted. Omitting
          it on a permissionless embed produces the same markup as an
          UNSANDBOXED frame — the one mistake here that grants everything while
          looking like it grants nothing.
        * The tokens ride in the vocabulary's DECLARATION order, de-duplicated,
          so two documents naming the same set produce identical markup whatever
          order they authored.
        * A REFUSED SOURCE OMITS THE ATTRIBUTE ENTIRELY rather than pointing the
          browsing context at the refusal URL — an iframe at that URL renders
          that page. The refusal is still RECORDED, and the frame is still
          emitted, named and sandboxed.
        """
        resolved = resolve_binding(fields.get("src"), self.sources)
        safe, refusal = sanitize_embed_src_for_egress(self.egress_policy, resolved if isinstance(resolved, str) else "")
        declared: list[str] = []
        permissions = fields.get("permissions")
        granted = {str(pterm) for pterm in permissions.items} if isinstance(permissions, Arr) else set()
        for wire, token in Renderer._SANDBOX_TOKENS:
            if wire in granted:
                declared.append(token)
        aspect = fields.get("aspectRatio")
        aspect_class = Renderer._EMBED_ASPECT_CLASS.get(aspect, "") if isinstance(aspect, str) else ""
        attrs: list[tuple[str, str]] = [
            ("class", "fuaran-embed" + aspect_class),
            ("title", self._text(fields.get("title"))),
            ("sandbox", " ".join(declared)),
            ("loading", "lazy"),
            ("referrerpolicy", "strict-origin-when-cross-origin"),
        ]
        if safe is not None:
            attrs.append(("src", safe))
        if "AllowFullscreen" in granted:
            attrs.append(("allow", "fullscreen"))
        attrs.extend(semantic_attrs)
        attrs.extend(refusal)
        # `element`, not `void_element`: `<iframe>` is NOT a void element, and a
        # self-closed one leaves the parser inside it — the `<video>` trap one
        # kind over.
        return element("iframe", attrs, "")

    def _tree(self, node: Node, fields: dict[str, Value]) -> str:
        """fuaran#1120 — the tree, and its floor is NORMATIVE rather than a
        degraded approximation: nested lists carrying the full ARIA tree
        vocabulary, `aria-expanded` reflecting the statically-resolvable expanded
        state, and exactly ONE row carrying `tabindex="0"`.

        No script participates at any point, so what a reader with JavaScript off
        gets is a complete, navigable, correctly-announced hierarchy that simply
        does not toggle. Movement is an interactive host's ADDITION over this
        identical DOM, never a precondition for the document being readable.

        Three decisions are worth stating because a host would round-trip the
        bytes perfectly having got each of them wrong:

        * The ACCESSIBLE NAME IS STATED, not computed from contents. A
          `treeitem` OWNS its child group, so a name derived from its subtree
          reads the whole branch out as the row's own name.
        * `aria-expanded` is emitted ONLY on a row that HAS children. On a leaf
          it asserts a collapsed subtree that does not exist, and assistive
          technology announces such a row as CLOSED — a reader told there is more
          when there is not.
        * `aria-selected` appears only where a selection key is NAMED. Emitting
          `false` on every row of a tree that never selects declares a selectable
          widget with nothing selected, rather than a tree that does not select.
        """
        expanded_key = fields.get("expandedStateKey")
        key_named = isinstance(expanded_key, str)
        expanded = self._tree_expanded_ids(expanded_key)
        selection_key = fields.get("selectionStateKey")
        selected = self._tree_selected_id(selection_key)
        items = fields.get("items")
        roots = items.items if isinstance(items, Arr) else []
        focusable = _focusable_tree_item(key_named, expanded, selected, roots)

        def render_items(level: int, rows: Sequence[Value]) -> str:
            out: list[str] = []
            set_size = len(rows)
            for index, row in enumerate(rows):
                if not isinstance(row, Obj):
                    continue
                row_id = row.fields.get("id")
                row_id = row_id if isinstance(row_id, str) else ""
                children = row.fields.get("children")
                child_rows = children.items if isinstance(children, Arr) else []
                is_open = _tree_item_expanded(key_named, expanded, row_id, bool(child_rows))
                label = self._text(row.fields.get("label"))
                attrs: list[tuple[str, str]] = [
                    ("class", "fuaran-tree-item"),
                    ("role", "treeitem"),
                    ("aria-label", label),
                    ("aria-level", str(level)),
                    ("aria-setsize", str(set_size)),
                    ("aria-posinset", str(index + 1)),
                    ("data-fuaran-tree-item", row_id),
                    ("tabindex", "0" if row_id == focusable else "-1"),
                ]
                if child_rows:
                    attrs.append(("aria-expanded", "true" if is_open else "false"))
                if isinstance(selection_key, str):
                    attrs.append(("aria-selected", "true" if row_id == selected else "false"))
                body = text_element("span", [("class", "fuaran-tree-label")], label)
                if is_open:
                    body += element(
                        "ul",
                        [("class", "fuaran-tree-group"), ("role", "group")],
                        render_items(level + 1, child_rows),
                    )
                out.append(element("li", attrs, body))
            return "".join(out)

        return element(
            "ul",
            [("class", "fuaran-tree"), ("role", "tree")],
            render_items(1, roots),
        )

    def _tree_expanded_ids(self, key: Value | None) -> frozenset[str]:
        """The rows a tree currently has OPEN, read off the named State key.

        The fixed shape is a JSON ARRAY OF ROW IDS. Every non-conforming shape
        reads as the EMPTY SET rather than as an error: a key holding a number, an
        object, or an array with non-string members is a HOST'S state slot, not a
        wire document, so there is nothing here to refuse and refusing would blank
        a tree over a value the reader never authored. Non-string members are
        dropped individually for the same reason — `["a", 3, "b"]` still says two
        true things.
        """
        if not isinstance(key, str):
            return frozenset()
        raw = as_sources(self.sources).values.get(key)
        if isinstance(raw, Arr):
            return frozenset(v for v in raw.items if isinstance(v, str))
        if isinstance(raw, list):
            return frozenset(v for v in raw if isinstance(v, str))
        return frozenset()

    def _tree_selected_id(self, key: Value | None) -> str | None:
        """The SELECTED row, read off the named State key. The fixed shape is a
        bare row-id STRING, so `None` covers both an unset key and a key holding
        anything else, on the expansion slot's reasoning."""
        if not isinstance(key, str):
            return None
        raw = as_sources(self.sources).values.get(key)
        return raw if isinstance(raw, str) and raw != "" else None

    def _media(self, node: Node, fields: dict[str, Value], semantic_attrs: Sequence[tuple[str, str]] = ()) -> str:
        """fuaran#1076 — the media transport. Deterministic, script-free markup: a
        real ``<video>`` / ``<audio>`` a browser plays with no runtime, exactly as
        ``Image`` emits a real ``<img>``.

        Four things here are CONTRACT rather than choice, and each is stated
        normatively in the wire spec (§3.6.6) because a host that got any of them
        wrong would still round-trip the bytes perfectly:

        * ``aria-label`` ALWAYS. The label is mandatory on the wire and there is
          no decorative case, so unlike ``Image``'s ``alt`` there is no branch.
        * ``autoplay`` NEVER WITHOUT ``muted``. The pairing is not a default a
          caller can override — it is what the declaration MEANS, which is why the
          wire carries no separate ``muted`` slot to get out of step with it.
          Every mainstream browser blocks unmuted autoplay anyway, so an unmuted
          emission would produce a player that silently never starts: the
          declaration would be a lie and the failure would be invisible. The
          converse holds too — no ``muted`` where ``autoplay`` is absent.
        * NO AUTOPLAY PATHWAY ON AUDIO, at all. Not "off by default": the
          ``Audio`` case carries no slot to read, so this arm has nothing to
          branch on and cannot acquire one by a later edit here.
        * BOTH URLS THROUGH THE EGRESS FLOOR. ``src`` and ``poster`` are each
          fetched with no user act. They differ in what a REFUSAL means: an
          element must have a source, so ``src`` collapses to the refusal URL and
          carries the marker, while a poster simply LEAVES — a ``<video>`` with no
          poster shows its first frame, which is a working rendering, whereas a
          poster pointing at the refusal URL is a broken image painted over the
          player.

        fuaran#1110 adds three more of the same kind, all of them in
        :meth:`_media_tracks` and :meth:`_media_transcript`: authored track ORDER
        is preserved, at most one ``default`` survives per KIND, and a declared
        transcript renders BESIDE the transport rather than inside it.
        """
        src_value = resolve_binding(fields.get("src"), self.sources)
        src, egress_attrs = sanitize_url_for_egress(
            self.egress_policy, EgressClass.MEDIA, src_value if isinstance(src_value, str) else ""
        )
        kind = fields.get("kind")
        variant = kind.tag if isinstance(kind, Obj) else "Video"
        shared: list[tuple[str, str]] = [
            ("src", src),
            ("aria-label", self._text(fields.get("label"))),
        ]
        if fields.get("controls") is not False:
            shared.append(("controls", ""))
        if fields.get("loop") is True:
            shared.append(("loop", ""))
        tracks_html = self._media_tracks(fields.get("tracks"))
        if variant == "Audio":
            # `element`, not `void_element`: `<video>` / `<audio>` are NOT void
            # elements. A self-closed `<audio …/>` leaves the parser inside the
            # element and swallows the rest of the document as its fallback
            # content — the one mistake here that produces a page which looks
            # broken everywhere EXCEPT the node that caused it.
            return self._media_transcript(
                element(
                    "audio",
                    [("class", "fuaran-media fuaran-media-audio"), *shared, *semantic_attrs, *egress_attrs],
                    tracks_html,
                ),
                fields,
            )
        kind_fields = kind.fields if isinstance(kind, Obj) else {}
        poster_attrs: list[tuple[str, str]] = []
        if "poster" in kind_fields:
            resolved = resolve_binding(kind_fields.get("poster"), self.sources)
            safe_poster, poster_refusal = sanitize_url_for_egress(
                self.egress_policy, EgressClass.MEDIA, resolved if isinstance(resolved, str) else ""
            )
            if safe_poster != "" and not poster_refusal:
                poster_attrs.append(("poster", safe_poster))
        autoplay_attrs: list[tuple[str, str]] = (
            [("autoplay", ""), ("muted", "")] if kind_fields.get("autoplay") is True else []
        )
        return self._media_transcript(
            element(
                "video",
                [
                    ("class", "fuaran-media fuaran-media-video"),
                    *shared,
                    *poster_attrs,
                    *autoplay_attrs,
                    *semantic_attrs,
                    *egress_attrs,
                ],
                tracks_html,
            ),
            fields,
        )

    #: The lower-case HTML token each wire ``TrackKind`` case emits as. The wire
    #: spells the case; HTML spells the attribute, and the two are deliberately
    #: not the same string — a renderer emitting the wire spelling would produce
    #: a `kind` no user agent recognises.
    _TRACK_KIND_TOKENS = {
        "Subtitles": "subtitles",
        "Captions": "captions",
        "Descriptions": "descriptions",
        "Chapters": "chapters",
    }

    def _media_tracks(self, raw: Value | None) -> str:
        """fuaran#1110 — the ``<track>`` children. Three render obligations live
        in this one fold, and none of them is anything the bytes can carry:

        * AUTHORED ORDER is preserved. The list is emitted exactly as the wire
          carries it. This is the OPPOSITE of ``srcSet``, which this renderer
          sorts ascending by width, and the difference is not an inconsistency: a
          browser picks ONE candidate from a srcset by an algorithm, while a
          reader picks a track from a menu the user agent builds in document
          order. Sorting the first is canonicalisation; sorting the second would
          be reordering someone else's menu.
        * ONE ``default`` PER KIND, FIRST WINS. A document electing two default
          captions tracks is legal bytes — the decoder does not refuse it,
          because a lenient host would render it anyway and HTML leaves the case
          undefined — so the host resolves it, and every host resolves it the
          same way. The later track is still EMITTED; only its claim on the menu
          is dropped.
        * A REFUSED SOURCE DROPS THE TRACK. The poster rule rather than the
          source rule: an element must have a source, but it need not have this
          track, and a ``<track>`` pointing at the refusal URL is a menu entry
          that opens onto nothing.
        """
        if not isinstance(raw, Arr):
            return ""
        claimed: set[str] = set()
        out: list[str] = []
        for entry in raw.items:
            if not isinstance(entry, Obj):
                continue
            resolved = resolve_binding(entry.fields.get("src"), self.sources)
            safe, refusal = sanitize_url_for_egress(
                self.egress_policy, EgressClass.MEDIA, resolved if isinstance(resolved, str) else ""
            )
            if safe == "" or refusal:
                continue
            kind = entry.fields.get("kind")
            token = self._TRACK_KIND_TOKENS.get(kind, "") if isinstance(kind, str) else ""
            src_lang = entry.fields.get("srcLang")
            takes_default = entry.fields.get("default") is True and token not in claimed
            if takes_default:
                claimed.add(token)
            attrs: list[tuple[str, str]] = [
                ("kind", token),
                ("src", safe),
                ("srclang", src_lang if isinstance(src_lang, str) else ""),
                ("label", self._text(entry.fields.get("label"))),
            ]
            if takes_default:
                attrs.append(("default", ""))
            out.append(void_element("track", attrs))
        return "".join(out)

    def _media_transcript(self, transport: str, fields: dict[str, Value]) -> str:
        """fuaran#1110 — the transcript disclosure, rendered BESIDE the transport
        rather than inside it.

        ``<video>`` and ``<audio>`` admit only source-ish children, so a
        transcript placed there would be fallback content a browser never shows —
        which is why a present transcript is the one case where the emission
        gains a wrapper. Absent, the emission is the bare element it would
        otherwise be, exactly as an uncaptioned ``Image`` emits no ``<figure>``.

        The ``<details>`` carries the MEDIA's resolved label as its own
        accessible name, so a reader meeting the disclosure out of context is
        told which recording it transcribes. The summary text is renderer chrome
        (the ``Toast`` dismiss precedent); the transcript itself is the
        document's.
        """
        transcript = fields.get("transcript")
        if transcript is None:
            return transport
        disclosure = element(
            "details",
            [("class", "fuaran-media-transcript"), ("aria-label", self._text(fields.get("label")))],
            text_element("summary", [("class", "fuaran-media-transcript-summary")], "Transcript")
            + text_element("div", [("class", "fuaran-media-transcript-body")], self._text(transcript)),
        )
        return element("div", [("class", "fuaran-media-group")], transport + disclosure)

    def _list(self, node: Node, fields: dict[str, Value]) -> str:
        raw = fields.get("items")
        items_html = ""
        if isinstance(raw, Arr):
            items_html = "".join(
                text_element("li", [("class", "fuaran-list-item")], self._text(item)) for item in raw.items
            )
        if fields.get("ordered") is True:
            return element("ol", [("class", "fuaran-list fuaran-list-ordered")], items_html)
        return element("ul", [("class", "fuaran-list fuaran-list-unordered")], items_html)

    def _toast(self, node: Node, fields: dict[str, Value]) -> str:
        # Overlay render-fidelity contract (server half): ALWAYS emitted; closed =
        # the `hidden` attribute. role="status" + aria-live="polite".
        is_open = resolve_binding(fields.get("open"), self.sources) is True
        tone = str(fields.get("tone", "Default")).lower()
        parts = [text_element("span", [("class", "fuaran-toast-message")], self._text(fields.get("message")))]
        if fields.get("dismissable") is True:
            parts.append(
                text_element(
                    "button",
                    [("class", "fuaran-toast-dismiss"), ("type", "button"), ("aria-label", "Dismiss")],
                    "×",
                )
            )
        attrs: list[tuple[str, str]] = [
            ("class", f"fuaran-toast fuaran-toast-{tone}"),
            ("role", "status"),
            ("aria-live", "polite"),
        ]
        if not is_open:
            attrs.append(("hidden", ""))
        return element("div", attrs, "".join(parts))

    def _code_block(self, node: Node, fields: dict[str, Value]) -> str:
        # Phase 290 — deterministic `<pre><code>` (HTML-escaped, no markdown).
        # Syntax highlighting is a client-only enhancement targeting
        # `.language-{x}`, so it is outside the parity output.
        language = fields.get("language")
        language = language if isinstance(language, str) else ""
        line_numbers = fields.get("lineNumbers") is True
        container_class = "fuaran-codeblock fuaran-codeblock-numbered" if line_numbers else "fuaran-codeblock"
        attrs: list[tuple[str, str]] = [("class", container_class), ("data-language", language)]
        highlight = fields.get("highlightLines")
        if isinstance(highlight, Arr) and highlight.items:
            attrs.append(("data-highlight-lines", ",".join(str(n) for n in highlight.items)))
        parts: list[str] = []
        if fields.get("copyable") is True:
            parts.append(
                text_element(
                    "button",
                    [("class", "fuaran-codeblock-copy"), ("type", "button"), ("aria-label", "Copy")],
                    "Copy",
                )
            )
        code = fields.get("code")
        code = code if isinstance(code, str) else ""
        code_el = text_element(
            "code",
            [("class", f"fuaran-codeblock-code language-{language}")],
            code,
        )
        parts.append(element("pre", [("class", "fuaran-codeblock-pre")], code_el))
        return element("div", attrs, "".join(parts))

    def _math(self, node: Node, fields: dict[str, Value]) -> str:
        # Phase 293 — deterministic escaped-source fallback; KaTeX is a
        # client-only enhancement targeting `.fuaran-math-source` (outside parity).
        source = fields.get("source")
        source = source if isinstance(source, str) else ""
        source_span = text_element("span", [("class", "fuaran-math-source")], source)
        if fields.get("display") == "Inline":
            return element(
                "span",
                [("class", "fuaran-math fuaran-math-inline"), ("data-math-display", "inline")],
                source_span,
            )
        return element(
            "div",
            [("class", "fuaran-math fuaran-math-block"), ("data-math-display", "block")],
            source_span,
        )

    # ── Drawing (Phase 525 — first-party inline SVG) ─────────────────────────
    #
    # The Python port of the F# `Fuaran.UI.Renderer.DrawingSvg` builder: static
    # geometry lowered to inline `<svg>` on the server, byte-identical to the F#
    # / TS hosts (same path `d`, Ordinal style-attr order, coordinate/number
    # form, XML escaping, open-shape `fill=none` defaults). `role="img"` +
    # optional `<title>`/`<desc>` (R3 a11y). First-party, stdlib-only.

    def _draw_style_attrs(self, style: Value, default_fill_none: bool) -> str:
        fields = style.fields if isinstance(style, Obj) else {}
        out = ""
        fill: object | None = None
        if "fill" in fields:
            fill = resolve_binding(fields["fill"], self.sources)
        elif default_fill_none:
            fill = "none"
        if fill is not None:
            # A paint is a CLOSED colour grammar, not a free string. `_draw_escape`
            # makes a value safe as MARKUP and says nothing about what it MEANS,
            # and `url(https://collector/x)` in an SVG `fill` names a paint server
            # the user agent FETCHES — on render, with no user act, outside the
            # egress policy. It also contains no character the generic CSS rule
            # forbids, which is why these two slots need a positive grammar. A
            # refused paint emits `none` rather than empty: an empty `fill`
            # INHERITS the enclosing group's paint instead of clearing it.
            out += f' fill="{_draw_escape(sanitize_paint_value(str(fill)))}"'
        if "opacity" in fields:
            v = resolve_binding(fields["opacity"], self.sources)
            if v is not None:
                out += f' opacity="{_draw_num(v)}"'
        if "stroke" in fields:
            v = resolve_binding(fields["stroke"], self.sources)
            if v is not None:
                out += f' stroke="{_draw_escape(sanitize_paint_value(str(v)))}"'
        if "strokeWidth" in fields:
            v = resolve_binding(fields["strokeWidth"], self.sources)
            if v is not None:
                out += f' stroke-width="{_draw_num(v)}"'
        # Text-only attrs (Phase 528.1): text-anchor, font-family, font-size,
        # font-weight — bare enum / string / number, emitted only when set.
        if "textAnchor" in fields:
            anchor = {"Start": "start", "Middle": "middle", "End": "end"}.get(str(fields["textAnchor"]), "start")
            out += f' text-anchor="{anchor}"'
        if "fontFamily" in fields:
            out += f' font-family="{_draw_escape(str(fields["fontFamily"]))}"'
        if "fontSize" in fields:
            out += f' font-size="{_draw_num(fields["fontSize"])}px"'
        if "emphasis" in fields:
            weight = {"Quiet": "300", "Normal": "400", "Loud": "700"}.get(str(fields["emphasis"]), "400")
            out += f' font-weight="{weight}"'
        # Phase 642 — keyed mark identity: a data-bearing shape's derivation-based
        # id rides into the emitted SVG so marks are addressable (object
        # constancy) — last in the fixed attribute order.
        if "markId" in fields:
            out += f' data-fuaran-mark="{_draw_escape(str(fields["markId"]))}"'
        return out

    def _draw_stroke_join_attrs(self, style: Value) -> str:
        """Round line joins + caps on a STROKED path shape (``Polyline`` /
        ``Polygon`` / ``Curve``). A RENDERER default, not a wire field: no
        fixture changes shape, and every host emits the same two attributes
        from its own builder. SVG's initial ``stroke-linejoin`` is ``miter``,
        which spikes at the acute vertices a data polyline routinely has — a
        visible artefact that carries no data.

        Emitted only when the shape actually strokes, so a fill-only polygon
        (an area band) keeps its minimal attribute set. ``Line`` is
        deliberately excluded: a round cap on the axis and gridline rules
        would overhang each end by half the stroke width, lengthening chrome
        that is positioned exactly.
        """
        fields = style.fields if isinstance(style, Obj) else {}
        if "stroke" in fields and resolve_binding(fields["stroke"], self.sources) is not None:
            return ' stroke-linejoin="round" stroke-linecap="round"'
        return ""

    def _draw_tip_child(self, style: Value | None) -> str:
        """Phase 883 — the mark's hover readout as an SVG ``<title>`` CHILD of its own element.

        That single element is both the native browser tooltip and the element's
        accessible name, with no script, so a statically-served page carries the
        readout too. ``<title>`` must be the FIRST child to be the accessible
        name, which is why every arm below emits it ahead of any other content.

        A tip is the one ``DrawStyle`` field honoured on EVERY shape rather than
        only on ``Label`` — the marks a reader hovers are bars, wedges and
        points, and a ``<title>`` is inert geometry-wise on all of them (unlike
        ``rotation``, whose off-``Label`` emission would MOVE GEOMETRY).

        The text is XML-escaped through the same ``_draw_escape`` the label text
        and the drawing title/desc already use: this builder emits raw markup, so
        the escape is the whole defence, and the chart lowering feeds it
        UNTRUSTED series/category strings straight off the data feed.
        """
        fields = style.fields if isinstance(style, Obj) else {}
        tip = fields.get("tip")
        if tip is None:
            return ""
        return f"<title>{_draw_escape(self._text(tip))}</title>"

    def _draw_close(self, style: Value | None, element_name: str) -> str:
        """The tail of a shape element carrying no child content of its own.

        Self-closing when untipped — byte-unchanged from every pre-883 drawing —
        and an open/close pair wrapping the ``<title>`` when tipped.
        """
        fields = style.fields if isinstance(style, Obj) else {}
        if "tip" not in fields:
            return "/>"
        return f">{self._draw_tip_child(style)}</{element_name}>"

    def _draw_shape(self, sh: Value) -> str:
        if not isinstance(sh, Obj):
            return ""
        tag = sh.tag
        f = sh.fields
        style = f.get("style")
        if tag == "Group":
            children = f.get("children")
            inner = "".join(self._draw_shape(c) for c in children.items) if isinstance(children, Arr) else ""
            return (
                f'<g class="fuaran-drawing-group"{self._draw_style_attrs(style, False)}>'
                f"{self._draw_tip_child(style)}{inner}</g>"
            )
        if tag == "Rectangle":
            rx = f' rx="{_draw_num(f["cornerRadius"])}"' if "cornerRadius" in f else ""
            return (
                f'<rect class="fuaran-drawing-rect" x="{_draw_num(f.get("x", 0))}"'
                f' y="{_draw_num(f.get("y", 0))}" width="{_draw_num(f.get("width", 0))}"'
                f' height="{_draw_num(f.get("height", 0))}"{rx}'
                f"{self._draw_style_attrs(style, False)}{self._draw_close(style, 'rect')}"
            )
        if tag == "Line":
            return (
                f'<line class="fuaran-drawing-line" x1="{_draw_num(f.get("x1", 0))}"'
                f' y1="{_draw_num(f.get("y1", 0))}" x2="{_draw_num(f.get("x2", 0))}"'
                f' y2="{_draw_num(f.get("y2", 0))}"{self._draw_style_attrs(style, False)}'
                f"{self._draw_close(style, 'line')}"
            )
        if tag == "Polyline":
            return (
                f'<polyline class="fuaran-drawing-polyline" points="{_draw_points(f.get("points"))}"'
                f"{self._draw_style_attrs(style, True)}{self._draw_stroke_join_attrs(style)}"
                f"{self._draw_close(style, 'polyline')}"
            )
        if tag == "Polygon":
            return (
                f'<polygon class="fuaran-drawing-polygon" points="{_draw_points(f.get("points"))}"'
                f"{self._draw_style_attrs(style, False)}{self._draw_stroke_join_attrs(style)}"
                f"{self._draw_close(style, 'polygon')}"
            )
        if tag == "Curve":
            return (
                f'<path class="fuaran-drawing-curve" d="{_draw_path_d(f.get("commands"))}"'
                f"{self._draw_style_attrs(style, True)}{self._draw_stroke_join_attrs(style)}"
                f"{self._draw_close(style, 'path')}"
            )
        if tag == "Circle":
            return (
                f'<circle class="fuaran-drawing-circle" cx="{_draw_num(f.get("cx", 0))}"'
                f' cy="{_draw_num(f.get("cy", 0))}" r="{_draw_num(f.get("r", 0))}"'
                f"{self._draw_style_attrs(style, False)}{self._draw_close(style, 'circle')}"
            )
        if tag == "Ellipse":
            return (
                f'<ellipse class="fuaran-drawing-ellipse" cx="{_draw_num(f.get("cx", 0))}"'
                f' cy="{_draw_num(f.get("cy", 0))}" rx="{_draw_num(f.get("rx", 0))}"'
                f' ry="{_draw_num(f.get("ry", 0))}"{self._draw_style_attrs(style, False)}'
                f"{self._draw_close(style, 'ellipse')}"
            )
        if tag == "Label":
            # Phase 877 — the rotation transform is built HERE rather than in
            # `_draw_style_attrs` because the pivot is the label's own anchor
            # point, which the style record does not carry; `_draw_style_attrs`
            # is shared by every shape and stays position-free. Anchoring at
            # (x, y) is what makes the rotation compose with `textAnchor` — the
            # text turns about the point it is aligned to. Degrees, clockwise
            # (SVG's own convention), so no sign conversion is needed.
            #
            # Deliberately never emitted off `Label`: an SVG transform on a
            # <rect> would MOVE GEOMETRY rather than be inert as the other
            # text-only fields are.
            x, y = f.get("x", 0), f.get("y", 0)
            style_fields = style.fields if isinstance(style, Obj) else {}
            rot = ""
            if "rotation" in style_fields:
                rot = f' transform="rotate({_draw_num(style_fields["rotation"])} {_draw_num(x)} {_draw_num(y)})"'
            return (
                f'<text class="fuaran-drawing-label" x="{_draw_num(x)}"'
                f' y="{_draw_num(y)}"{rot}{self._draw_style_attrs(style, False)}>'
                # The tip precedes the visible run — `<title>` is the
                # accessible name only as the FIRST child.
                f"{self._draw_tip_child(style)}"
                f"{_draw_escape(self._text(f.get('text')))}</text>"
            )
        return ""

    @staticmethod
    def _terminate_title(t: str) -> str:
        """Phase 921 — terminate a title with ``.`` unless it already ends in
        sentence punctuation, so the composed label reads as two sentences
        rather than one run-on."""
        if t == "" or t[-1] in ".!?":
            return t
        return t + "."

    def _root_aria_label(self, title: Value | None, description: Value | None) -> str:
        """Phase 921 — the drawing root's ANNOUNCED accessible name.

        ``role="img"`` presents the drawing as ONE graphic and does not traverse
        into it, and ``<desc>`` is not uniformly mapped to the accessible
        description (Chromium has never exposed it) — so the value the markup has
        carried since Phase 525 is one a reader cannot reach. ``aria-label`` is
        the accessible NAME, which every assistive technology announces
        unconditionally for a ``role="img"`` element.

        NOT ``aria-labelledby`` / ``aria-describedby``: both reference elements
        BY ID, and this builder has no id to give — its whole input is a drawing
        spec, several drawings routinely share one document, and any minted id
        would have to be both unique per page and byte-identical across five
        hosts.

        Emitted ONLY when a description is present, so every pre-921 title-only
        or bare drawing is byte-identical.
        """
        if description is None:
            return ""
        desc_text = self._text(description)
        title_text = self._terminate_title(self._text(title)) if title is not None else ""
        composed = f"{title_text} {desc_text}" if title_text != "" else desc_text
        return f' aria-label="{_draw_escape(composed)}"'

    def _drawing(self, node: Node, fields: dict[str, Value]) -> str:
        return element("div", [], self._drawing_svg(fields))

    def bare_drawing_svg(self, fields: dict[str, Value]) -> str:
        """The shared SVG builder — the `<svg class="fuaran-drawing">` element for
        a ``Drawing`` kind's fields, without the wrapping element.

        Split out of :meth:`_drawing` by Phase 1099 so a lowered kind can carry
        its OWN hook element (the `Sparkline` arm's ``fuaran-sparkline``
        container, where the sizing and the inherited ``color`` live) around the
        same bytes, exactly as the reference host's renderers call
        ``DrawingSvg.render`` beside a per-arm wrapper. Public since fuaran#1176,
        because the markdown projection embeds this element with no wrapper at
        all. It stays the geometry builder and never becomes a second renderer:
        a caller wanting different GEOMETRY is asking for a different lowering,
        not a different argument here.
        """
        vb = fields.get("viewBox")
        vb_fields = vb.fields if isinstance(vb, Obj) else {}
        view_box = " ".join(_draw_num(vb_fields.get(k, 0)) for k in ("minX", "minY", "width", "height"))
        title = ""
        t = fields.get("title")
        if t is not None:
            title = f"<title>{_draw_escape(self._text(t))}</title>"
        desc = ""
        d = fields.get("description")
        if d is not None:
            desc = f"<desc>{_draw_escape(self._text(d))}</desc>"
        shapes = fields.get("shapes")
        body = "".join(self._draw_shape(s) for s in shapes.items) if isinstance(shapes, Arr) else ""
        root_style = self._draw_style_attrs(fields.get("style"), False)
        aria = self._root_aria_label(t, d)
        return (
            f'<svg class="fuaran-drawing" role="img" viewBox="{view_box}"{aria}{root_style}>{title}{desc}{body}</svg>'
        )

    def _drawing_svg(self, fields: dict[str, Value]) -> str:
        """The `<svg>` inside the wrapping `<div>` both existing callers expect.

        Kept as its own step so :meth:`bare_drawing_svg` can hand out the element WITHOUT
        that wrapper — a markdown document embeds the SVG directly, where a `<div>` would be
        block-level HTML the surrounding markdown never asked for. Splitting rather than
        changing: both existing callers emit the same bytes they always did.
        """
        return element("div", [], self.bare_drawing_svg(fields))

    # ── inputs (inert — no dispatch server-side) ─────────────────────────────

    def _button(self, node: Node, fields: dict[str, Value], semantic_attrs: Sequence[tuple[str, str]] = ()) -> str:
        variant = str(fields.get("variant", "Primary")).lower()
        disabled = resolve_binding(fields.get("disabled"), self.sources)
        attrs: list[tuple[str, str]] = [("class", f"fuaran-button fuaran-button-{variant}")]
        tooltip = fields.get("tooltip")
        if tooltip is not None:
            attrs.append(("title", self._text(tooltip)))
        # Before `disabled`, matching the reference server renderer's order.
        attrs.extend(semantic_attrs)
        if disabled is True:
            attrs.append(("disabled", ""))
        return text_element("button", attrs, self._text(fields.get("label")))

    def _select(self, node: Node, fields: dict[str, Value]) -> str:
        label = element("span", [("class", "fuaran-select-label")], escape_text(self._text(fields.get("label"))))
        options_html = self._render_options(fields.get("source"), fields.get("placeholder"))
        disabled = resolve_binding(fields.get("disabled"), self.sources)
        select_attrs: list[tuple[str, str]] = [("class", "fuaran-select-control")]
        # Phase 291 — a multi-select emits the `multiple` attribute; a controlled
        # `<select multiple>` rejects a scalar `value`, so none is emitted here.
        if fields.get("multiple") is True:
            select_attrs.append(("multiple", ""))
        if disabled is True:
            select_attrs.append(("disabled", ""))
        control = element("select", select_attrs, options_html)
        return element("label", [("class", "fuaran-select")], label + control)

    def _render_options(self, source: Value, placeholder: Value) -> str:
        items: list[str] = []
        if placeholder is not None:
            items.append(text_element("option", [("value", "")], self._text(placeholder)))
        resolved = resolve_source(source, self.sources)
        if isinstance(resolved, Arr):
            for opt in resolved.items:
                if isinstance(opt, Obj):
                    value = opt.fields.get("value", "")
                    items.append(
                        text_element(
                            "option",
                            [("value", str(value))],
                            self._text(opt.fields.get("label", value)),
                        )
                    )
        return "".join(items)

    def _form(self, node: Node, fields: dict[str, Value]) -> str:
        field_html = ""
        raw_fields = fields.get("fields")
        if isinstance(raw_fields, Arr):
            field_html = "".join(self._form_field(f) for f in raw_fields.items if isinstance(f, Obj))
        submit = text_element(
            "button",
            [("class", "fuaran-form-submit"), ("type", "submit")],
            self._text(fields.get("submitLabel")),
        )
        return element("form", [("class", "fuaran-form")], field_html + submit)

    def _form_field(self, field: Obj) -> str:
        """A UNIFORM floor over the whole control vocabulary — deliberately.

        Every ``FormFieldKind`` renders as the same generic ``<input>`` carrying
        the field class, the field address and whatever HTML constraint
        attributes the field's ``rule`` projects to. No control kind gets bespoke
        markup: not ``Choice`` (which wants a ``<select>``), not ``TextArea``
        (``<textarea>``), not ``Checkbox`` (``type="checkbox"``), and not
        ``Combobox`` (``<input list>`` + ``<datalist>``). The single kind-aware
        branch in the whole path is a NEGATIVE one, in ``_field_rule_attrs``:
        ``<textarea>`` has no ``pattern`` attribute, so none is emitted for it.

        **``Combobox`` is exempt from a per-control SSR floor here, and the
        exemption is the uniformity above rather than an oversight** (fuaran#1128).
        The generated render-fidelity manifest declares NO obligation row for any
        control kind — ``Form``'s own row carries an empty ``obligations`` list and
        an empty ``fixtures`` list, and the string "Combobox" does not appear in
        the artefact at all — so nothing executable is being declined. Giving
        ``Combobox`` alone a native floor would make it the one control in fifteen
        with bespoke markup while ``Choice``, ``TextArea`` and ``Checkbox`` — each
        with a strictly stronger native-HTML case — stayed generic text inputs.
        That trades a coherent tier for a locally better one control, which is the
        wrong unit of work: the floor this host owes is the WHOLE control
        vocabulary, taken as one phase, not the control that happened to arrive
        most recently.

        Two constraints for whoever takes that phase, recorded because they were
        settled elsewhere and are easy to lose. A datalist-backed floor emits
        ``<input list>`` + ``<datalist>`` and **must not** emit
        ``role="combobox"`` / ``aria-expanded``: a static ``aria-expanded="false"``
        replaces the user agent's own correct semantics with a claim inert markup
        cannot keep. And ``allowFreeText=false`` is not enforceable server-side —
        record it as a data attribute if at all, never as a claim the markup keeps.
        """
        field_id = field.fields.get("id")
        field_id = field_id if isinstance(field_id, str) else ""
        label = element(
            "span", [("class", "fuaran-form-field-label")], escape_text(self._text(field.fields.get("label")))
        )
        control_kind = field.fields.get("kind")
        control_tag = control_kind.tag if isinstance(control_kind, Obj) else None
        attrs: list[tuple[str, str]] = [("class", "fuaran-form-field-control"), ("data-fuaran-field", field_id)]
        attrs.extend(_field_rule_attrs(field.fields.get("rule"), control_tag))
        control = void_element("input", attrs)
        return element("label", [("class", "fuaran-form-field")], label + control)

    def _filters(self, node: Node, fields: dict[str, Value]) -> str:
        # The structural decode does not give Filters a typed schema; render the
        # wrapper with the correct class so the host CSS hooks, and project any
        # nested filter specs best-effort (rare in the baseline corpus).
        return element("div", [("class", "fuaran-filters")], "")

    #: fuaran#1116 — the HTML `capture` keywords. They name a camera FACING, so
    #: the projection is `Camera` → `environment` and `Microphone` → `user`: both
    #: are conforming keywords, the facing constrains only a camera, and a host
    #: MUST NOT emit the device name itself, which is not a keyword and is
    #: non-conforming markup.
    _CAPTURE_KEYWORD = {"Camera": "environment", "Microphone": "user"}

    def _file_upload(self, node: Node, fields: dict[str, Value]) -> str:
        """The upload control, and the one obligation every variant of it shares:
        THE PICKER IS ALWAYS EMITTED.

        A declared ingress gesture is ADDITIONAL. Whatever the document says —
        drop target, paste, capture device, streamed destination — the file input
        and its label are emitted, so the keyboard-accessible route survives and
        a no-script host renders a working upload. There is no keyboard
        equivalent of a drag, so a control that replaced the picker with a drop
        zone would have removed the only route some readers have.

        The three routes DEGRADE differently here, and each says so:

        * `capture` FULLY HOLDS — it needs no listener, the user agent reads it
          off the markup, and a zero-JS document opens the camera exactly as a
          hydrated one does. `accept` is emitted exactly as declared and is never
          synthesised from the device: that would put a filter in the document's
          mouth that nobody wrote.
        * `dropTarget` / `acceptPaste` need an event listener and no CSS observes
          a drag, so this tier records the DECLARATION and draws no zone.
        * `destination` needs a listener AND a sink, so this tier records only
          THAT one was declared and never WHICH — the id is the host's registry
          key and a static document is readable by anyone.
        * `maxBytes` / `maxFiles` (fuaran#1548) degrade ENTIRELY, and for a
          plainer reason than the destination's: HTML has no attribute for a
          byte ceiling, and `multiple` is a boolean rather than a count, so
          there is nothing a zero-JS document could enforce. Each is recorded as
          READ and never by VALUE — nothing on this path can act on the number,
          so emitting it would invite a reader to believe this tier enforces it.
        """
        label = element("span", [("class", "fuaran-file-upload-label")], escape_text(self._text(fields.get("label"))))
        control_attrs: list[tuple[str, str]] = [("class", "fuaran-file-upload-input"), ("type", "file")]
        accept = fields.get("accept")
        if isinstance(accept, Arr) and accept.items:
            control_attrs.append(("accept", ",".join(str(a) for a in accept.items)))
        if fields.get("multiple") is True:
            control_attrs.append(("multiple", ""))
        capture = fields.get("capture")
        if isinstance(capture, str):
            control_attrs.append(("capture", Renderer._CAPTURE_KEYWORD[capture]))
        control = void_element("input", control_attrs)
        label_attrs: list[tuple[str, str]] = [("class", "fuaran-file-upload")]
        if fields.get("dropTarget") is True:
            label_attrs.append(("data-fuaran-upload-drop", "declared"))
        if fields.get("acceptPaste") is True:
            label_attrs.append(("data-fuaran-upload-paste", "declared"))
        if isinstance(fields.get("destination"), str):
            label_attrs.append(("data-fuaran-upload-destination", "declared"))
        for member, marker in (("maxBytes", "max-bytes"), ("maxFiles", "max-files")):
            ceiling = fields.get(member)
            # `bool` is an `int` subclass in Python, so it is excluded
            # explicitly — the same trap the decoder names at its own integer
            # slot. A decoded tree cannot carry one here, and a marker that
            # depended on that would be relying on a guarantee made elsewhere.
            if isinstance(ceiling, int) and not isinstance(ceiling, bool):
                label_attrs.append((f"data-fuaran-upload-{marker}", "declared"))
        return element("label", label_attrs, label + control)

    # ── visualisations ───────────────────────────────────────────────────────

    def _table(self, node: Node, fields: dict[str, Value]) -> str:
        headers = fields.get("headers")
        header_cells = ""
        if isinstance(headers, Arr):
            header_cells = "".join(
                text_element("th", [("class", "fuaran-table-header")], self._text(h)) for h in headers.items
            )
        rows = fields.get("rows")
        body_rows = ""
        if isinstance(rows, Arr):
            for row in rows.items:
                if isinstance(row, Arr):
                    cells = "".join(
                        text_element("td", [("class", "fuaran-table-cell")], self._text(c)) for c in row.items
                    )
                    body_rows += element("tr", [("class", "fuaran-table-row")], cells)
        thead = element("thead", [], element("tr", [], header_cells))
        tbody = element("tbody", [], body_rows)
        # Phase 801 — the declared sort intent as data attributes, so a
        # progressive-enhancement script honours it without re-parsing the wire.
        # Emitted ONLY when declared (an undeclared table's bytes are unchanged),
        # and in the same order as the F# / TS server renderers so the parity-locked
        # markup stays parity-locked.
        attrs: list[tuple[str, str]] = [("class", "fuaran-table")]
        sortable = fields.get("sortable")
        if isinstance(sortable, bool):
            attrs.append(("data-fuaran-sortable", "true" if sortable else "false"))
        default_sort = fields.get("defaultSort")
        if isinstance(default_sort, Obj):
            column = default_sort.fields.get("column")
            direction = default_sort.fields.get("direction")
            if isinstance(column, int) and isinstance(direction, str):
                attrs.append(("data-fuaran-sort-column", str(column)))
                attrs.append(("data-fuaran-sort-direction", direction))
        return element("table", attrs, thead + tbody)

    def _make_vis_placeholder(self, css: str, name: str, count: int, text: str) -> str:
        return text_element(
            "div",
            [
                ("class", css),
                ("data-fuaran-ssr-placeholder", name),
                ("data-fuaran-row-count", str(count)),
            ],
            text,
        )

    @staticmethod
    def _grid_columns(columns: Value) -> list[dict[str, Value]]:
        """The decoded ``columns`` list as plain field maps (non-objects dropped)."""
        if not isinstance(columns, Arr):
            return []
        return [c.fields for c in columns.items if isinstance(c, Obj)]

    @staticmethod
    def _grid_cell_text(column: dict[str, Value], row: Obj) -> str:
        """One bound-grid cell's text, mirroring the reference ``renderCellValue``.

        A column projects its cell either declaratively (``field`` — a row
        property name that rides the wire) or through a host closure (``value``).
        The closure does **not** survive serialisation, so a closure-projected
        column has no server-side cell value and renders empty — which is exactly
        what the reference renderer does with a decoded grid, for the same reason.
        """
        field = column.get("field")
        if not isinstance(field, str):
            return ""
        value = row.fields.get(field)
        if value is None:
            return ""
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, (int, float)):
            return format_number(column.get("format"), value)
        return str(value)

    def _bound_grid(self, columns: list[dict[str, Value]], rows: Arr, has_row_action: bool = False) -> str:
        """The resolved rows as the reference grid's own ``<table>`` markup.

        The element shape and class vocabulary match the reference renderer's
        simple-table grid path exactly (``fuaran-grid`` / ``-header`` / ``-row`` /
        ``-cell``, a ``<span>`` inside each cell), so a client that later hydrates
        this region re-renders into markup it already agrees with rather than
        replacing a foreign placeholder.

        Rich cell kinds (``TonedPill``, ``Checkbox``, ``Link``, ``Progress``, …)
        render their **text** projection here — this host's inert server semantics
        for every interactive node, not a special case for grids.
        """
        header_cells = "".join(
            text_element("th", [("class", "fuaran-grid-header")], str(c.get("label", ""))) for c in columns
        )
        body_rows = ""
        for row in rows.items:
            if not isinstance(row, Obj):
                continue
            cells = "".join(
                element(
                    "td",
                    [("class", "fuaran-grid-cell")],
                    text_element("span", [], self._grid_cell_text(c, row)),
                )
                for c in columns
            )
            # Phase 1701 - the row-action affordance marker (WIRE_FORMAT.md
            # 3.6.24). This host wires no click, but the class states what the
            # DOCUMENT declared, and the row it marks is the seed a hydrating
            # client takes over: a marked row here is a row that is about to
            # become clickable.
            row_class = "fuaran-grid-row" + grid_row_interactive_class(has_row_action)
            body_rows += element("tr", [("class", row_class)], cells)
        thead = element("thead", [], element("tr", [], header_cells))
        tbody = element("tbody", [], body_rows)
        return element("table", [("class", "fuaran-grid")], thead + tbody)

    def _data_grid(self, node: Node, fields: dict[str, Value]) -> str:
        # Phase 393 — a static read-only grid renders the semantic <table>
        # (byte-identical to the retired Table).
        #
        # Phase 668 — the bound-grid posture is COMPLETENESS, matching this
        # host's stated render-time compute model (Phase 648): a grid is data,
        # and a static host holding resolved rows while printing "hydrates
        # client-side" withholds what it already has. A no-JS surface (an email
        # digest, an ops report) can never recover it, and even where a client
        # does arrive, the placeholder is markup the client must REPLACE rather
        # than attach to.
        #
        # The boundary that remains is declared, not incidental: a cell is
        # projected either by `field` (declarative, on the wire) or by a host
        # closure (`value`), and a closure decodes as the `"<closure>"` sentinel.
        # So a grid declaring NO field-projected column at all — including one
        # declaring no columns — keeps the placeholder, because there is nothing
        # server-side to draw and the placeholder at least says so; a mixed grid
        # renders, with its closure-projected cells empty. A source that does not
        # resolve to rows (an unbound Query, an opaque `Static`) likewise keeps
        # the placeholder: same contract as before, now narrowed to the cases
        # that genuinely cannot be served.
        static_rows = fields.get("staticRows")
        if isinstance(static_rows, Obj):
            return self._table(node, static_rows.fields)
        resolved = resolve_source(fields.get("source"), self.sources)
        columns = self._grid_columns(fields.get("columns"))
        if isinstance(resolved, Arr) and any(isinstance(c.get("field"), str) for c in columns):
            return self._bound_grid(columns, resolved, "onRowClick" in fields)
        count = _seq_len(resolved)
        return self._make_vis_placeholder(
            "fuaran-grid fuaran-grid-ssr-placeholder",
            "DataGrid",
            count,
            f"[Grid: {count} rows {_EM_DASH} hydrates client-side]",
        )

    def _lower_chart(self, node: Node, fields: dict[str, Value], resolved: object) -> str | None:
        """Lower a resolved chart to a Drawing + render inline SVG, wrapped as the
        HTML page emits it.

        Returns ``None`` (fall through to the placeholder) when the kind is not
        lowerable or the data source did not resolve to embedded rows.
        """
        drawing_node = self._lower_chart_node(node, fields, resolved)
        if drawing_node is None or not isinstance(drawing_node.kind, Obj):
            return None
        return self._drawing(drawing_node, drawing_node.kind.fields)

    def chart_svg(self, node: Node, fields: dict[str, Value]) -> str | None:
        """The bare inline ``<svg>`` for a lowerable chart, or ``None``.

        The picture without the page's wrapper, for a projection that has no page —
        fuaran#1176's markdown document embeds it directly. It resolves the source and
        lowers through exactly the path :meth:`_chart` takes, so a chart in a document is
        the chart on the page: same geometry, same bytes inside the element.
        """
        drawing_node = self._lower_chart_node(node, fields, resolve_source(fields.get("source"), self.sources))
        if drawing_node is None or not isinstance(drawing_node.kind, Obj):
            return None
        return self.bare_drawing_svg(drawing_node.kind.fields)

    def sparkline_svg(self, node: Node, fields: dict[str, Value]) -> str | None:
        """The bare inline ``<svg>`` for a resolved sparkline series, or ``None``.

        The :meth:`chart_svg` argument at a smaller size, through the same shared geometry
        builder :meth:`_sparkline` uses. ``None`` for an unresolved or empty series — the
        condition under which the page renders its em-dash rather than a picture.
        """
        from ..charts import try_lower_sparkline_node

        series = _float_series(resolve_binding(fields.get("source"), self.sources))
        drawing = try_lower_sparkline_node(node.id, series) if series is not None else None
        if drawing is None or not isinstance(drawing.kind, Obj):
            return None
        return self.bare_drawing_svg(drawing.kind.fields)

    def _lower_chart_node(self, node: Node, fields: dict[str, Value], resolved: object) -> Node | None:
        """Lower a resolved chart (every ``LOWERED_KINDS`` arm) to its canonical ``Drawing``
        node.

        Returns ``None`` when the kind is not lowerable or the data source did not resolve
        to embedded rows. Split from :meth:`_lower_chart` by fuaran#1176 so a projection
        that wants the geometry without the page's markup reaches the same lowering rather
        than a second one.
        """
        from ..charts import LOWERED_KINDS, ChartSpec, lower_node

        kind = fields.get("kind")
        if not isinstance(kind, str) or (kind not in LOWERED_KINDS and kind != "Column"):
            return None
        if not isinstance(resolved, Arr) or not resolved.items:
            return None

        rows: list[dict[str, object]] = []
        for item in resolved.items:
            if not isinstance(item, Obj):
                return None
            rows.append(dict(item.fields))

        x_field = fields.get("xField")
        y_fields_raw = fields.get("yFields")
        if not isinstance(x_field, str) or not isinstance(y_fields_raw, Arr):
            return None
        y_fields = tuple(y for y in y_fields_raw.items if isinstance(y, str))

        # Phase 1143 — the four TextSource-typed fields (title, xTitle, yTitle,
        # subtitle) cross the bridge UNRESOLVED, whichever arm they carry. The
        # lowering reaches its labels with the text source itself and a Bound or
        # I18n arm resolves at RENDER time, where this host's sources and
        # catalogue are; the lowering reserves space by the PRESENCE of these
        # fields and never by their text, which is what makes that affordable.
        #
        # This bridge kept the LITERAL arm only until 1143 and dropped the rest,
        # so an authored I18n title vanished from a localised chart and a bound
        # axis name was silently replaced by a capitalised column name. The
        # cross-host statement is the reference host's
        # ``docs/CHART-LOWERING-TEXT-CONTRACT.md``; a bare string is still the
        # canonical Literal spelling and needs no unwrapping — an absent field
        # is absent, which is what ``.get`` already yields.
        stacked = fields.get("stacked") is True

        # Phase 876 — the declared value-axis number format crosses the bridge
        # as its canonical wire mapping (the shape the lowering reads).
        # `axisUnitMode` is a STYLE selector, not a wire field — never read here.
        value_format_src = fields.get("valueFormat")
        value_format: dict[str, object] | None = None
        if isinstance(value_format_src, Obj) and isinstance(value_format_src.tag, str):
            value_format = {"$type": value_format_src.tag, **value_format_src.fields}

        # Phase 880 — the legend edge (bare enum name; absent means the host
        # default, the explicit "None" suppresses the legend).
        legend_position_src = fields.get("legendPosition")
        legend_position = legend_position_src if isinstance(legend_position_src, str) else None

        # Phase 881 — whether the values are written onto the picture (bare enum
        # name; absent means "Off", which is also the default, so a headless
        # render of a pre-881 tree is byte-unchanged).
        data_labels_src = fields.get("dataLabels")
        data_labels = data_labels_src if isinstance(data_labels_src, str) else None

        # Phase 882 — what the x column MEANS (bare enum name; absent means
        # "Category", which is also the default, so a headless render of a
        # pre-882 tree is byte-unchanged).
        x_scale_src = fields.get("xScale")
        x_scale = x_scale_src if isinstance(x_scale_src, str) else None

        # Phase 1490/1491/1492 — the data-addressed annotations (§4l). Semantic
        # through and through: WHERE in the data a threshold, an episode or a
        # shock sits is the author's meaning, and the lowering owns every pixel
        # that draws it. Each annotation's LABEL crosses UNRESOLVED, whichever arm
        # it carries, on the Phase 1143 text contract — the lowering's fit gate is
        # confined to the literal arm precisely so it never measures text it
        # cannot know. Absent stays absent, so a pre-1490 tree lowers unchanged.
        annotations_src = fields.get("annotations")
        annotations = (
            [a for a in annotations_src.items if isinstance(a, Obj)] if isinstance(annotations_src, Arr) else None
        )

        spec = ChartSpec(
            kind=kind,
            x_field=x_field,
            y_fields=y_fields,
            title=fields.get("title"),
            stacked=stacked,
            value_format=value_format,
            # Phase 878 — the axis names + the muted subtitle.
            x_title=fields.get("xTitle"),
            y_title=fields.get("yTitle"),
            subtitle=fields.get("subtitle"),
            legend_position=legend_position,
            data_labels=data_labels,
            x_scale=x_scale,
            annotations=annotations,
        )
        return lower_node(node.id, spec, rows)

    def _chart(self, node: Node, fields: dict[str, Value]) -> str:
        resolved = resolve_source(fields.get("source"), self.sources)
        # First-party lowering (Phase 534): a Bar/Column/Line chart with resolved
        # rows lowers to a canonical Drawing subtree and renders as real inline SVG,
        # headless included. Anything unresolved / not-yet-lowered falls through to
        # the client-hydration placeholder.
        lowered = self._lower_chart(node, fields, resolved)
        if lowered is not None:
            return lowered
        count = _seq_len(resolved)
        title = fields.get("title")
        title_html = (
            text_element("div", [("class", "fuaran-chart-title")], self._text(title)) if title is not None else ""
        )
        body = element(
            "div",
            [("class", "fuaran-chart-placeholder")],
            escape_text(f"[Chart: {count} rows {_EM_DASH} hydrates client-side]"),
        )
        return element(
            "div",
            [
                ("class", "fuaran-chart fuaran-chart-ssr-placeholder"),
                ("data-fuaran-ssr-placeholder", "Chart"),
                ("data-fuaran-row-count", str(count)),
            ],
            title_html + body,
        )

    def _map(self, node: Node, fields: dict[str, Value]) -> str:
        count = _seq_len(resolve_source(fields.get("source"), self.sources))
        return text_element(
            "div",
            [
                ("class", "fuaran-map fuaran-map-ssr-placeholder"),
                ("data-fuaran-ssr-placeholder", "Map"),
                ("data-fuaran-marker-count", str(count)),
            ],
            f"[Map: {count} markers {_EM_DASH} hydrates client-side]",
        )

    # ── structural ───────────────────────────────────────────────────────────

    def _error_boundary(self, node: Node, fields: dict[str, Value]) -> str:
        child = _as_node(fields.get("child"))
        return self.render_node(child) if child is not None else ""

    def _switch(self, node: Node, fields: dict[str, Value]) -> str:
        # State-bound conditional child (Phase 392). Resolve the initial state
        # value at `stateKey` from the host sources; render the first case whose
        # `match` equals its string form (first-match-wins), else the default.
        # Server + client first render read the same initial state → hydration
        # parity; the Pyodide client re-renders on a SetState state change.
        state_key = fields.get("stateKey")
        cases = fields.get("cases")
        default = _as_node(fields.get("default"))

        current: object | None = None
        # Phase 1663 — the identity-keyed map is `values` on the widened record.
        values = as_sources(self.sources).values
        if isinstance(state_key, str) and state_key in values:
            current = values[state_key]
        elif "on" in fields:
            # fuaran#1535 — the Phase-768 ``on`` form, which this renderer read
            # ``stateKey``-only until now: a Selection / Filter / Query / Now
            # selector resolved to nothing here, so every such switch rendered its
            # default. Resolved through the SCALAR path, so a ``Transform`` or an
            # ``Expr`` yielding one cell reaches it too — the wire-neutral half of
            # this phase.
            current = resolve_scalar_text(fields["on"], self.sources)
        value_str = None if current is None else str(current)

        # fuaran#1535 — first-match-wins over BOTH kinds of case, through the one
        # shared definition, so every rendering surface in this package selects
        # identically.
        child = _as_node(select_switch_case(cases, value_str, self.sources))
        if child is not None:
            return self.render_node(child)
        return self.render_node(default) if default is not None else ""

    def _fragment_decl(self, node: Node, fields: dict[str, Value]) -> str:
        return ""  # zero-paint — the decl is a template, not visible output.

    def _fragment_ref(self, node: Node, fields: dict[str, Value]) -> str:
        name = fields.get("name")
        if isinstance(name, str):
            body = self.fragments.get(name)
            if body is not None:
                return self.render_node(body)
            return text_element(
                "div",
                [
                    ("class", "fuaran-fragment-unresolved-placeholder"),
                    ("data-fuaran-fragment-unresolved", name),
                ],
                f"[fuaran:fragment unresolved '{name}']",
            )
        return ""

    def _custom(self, node: Node, fields: dict[str, Value]) -> str:
        module_id = str(fields.get("moduleId", ""))
        component_id = str(fields.get("componentId", ""))
        return text_element(
            "div",
            [
                ("class", f"fuaran-kind-custom-placeholder fuaran-custom-{module_id}-{component_id}"),
                ("data-fuaran-custom-module", module_id),
                ("data-fuaran-custom-component", component_id),
            ],
            f"[fuaran:custom {module_id}.{component_id}]",
        )


def _float_seq_element(item: object) -> float:
    """One element of a float sequence, per WIRE_FORMAT.md §24.7 (fuaran#1704).

    The accept set is §7's and it is CLOSED: a JSON number, or one of the three
    quoted sentinel spellings. Anything else — a decimal string, a mis-cased
    sentinel, a bool, a mapping, a nested sequence — reads as NaN, which says
    "there is no number here" in the position where the number is not.

    ``bool`` is an ``int`` subclass in Python and is NOT a number here, for the
    reason the decoder refuses it in a numeric slot: ``True`` is not the value
    ``1`` that an author meant to plot.

    The closed set is not a narrowing for its own sake. ``float()`` accepts
    ``"3.5"`` but also ``"1_0"``, ``" nan "`` and ``"infinity"``; Go's
    ``ParseFloat`` accepts ``"0x1p-2"``; JavaScript's coercion accepts ``"0x10"``
    and the empty string — so "a numeric string" names a different set on every
    host, and one store would draw different pictures on two conformant hosts.
    This host's own decoder refuses exactly these spellings at the same slot, so
    admitting them here would make the two halves of one slot disagree about
    what a number is.
    """
    if isinstance(item, bool):
        return float("nan")
    if isinstance(item, (int, float)):
        return float(item)
    if item == "NaN":
        return float("nan")
    if item == "Infinity":
        return float("inf")
    if item == "-Infinity":
        return float("-inf")
    return float("nan")


def _float_series(value: object) -> list[float] | None:
    """A resolved ``Sparkline`` source as a float series, or ``None``.

    ``None`` means the resolved value was not a SEQUENCE at all — the unresolved
    case, which keeps the em-dash exactly as it always did. A value that IS a
    sequence yields ONE READING PER ELEMENT (WIRE_FORMAT.md §24.7), whatever the
    elements are.

    The decoder types this slot (a ``Binding<float seq>``, non-finites arriving
    as the §5/§7 quoted sentinels and leaving as floats), so a *decoded* tree
    cannot reach here with a foreign element at all. A host-supplied ``sources``
    value can, and this host used to treat that as "the source does not resolve
    to a series" and render the em-dash. §24.7 settles that it is not: the host
    demonstrably read the other elements, and discarding a hundred and
    ninety-nine readable points because the two-hundredth is junk tells the
    reader nothing at all, where the sentinel tells them one point is missing and
    leaves every other reading in its own position.
    """
    if not isinstance(value, (Arr, list, tuple)):
        return None
    items = value.items if isinstance(value, Arr) else list(value)
    return [_float_seq_element(item) for item in items]


def _seq_len(value: object) -> int:
    if isinstance(value, Arr):
        return len(value.items)
    if isinstance(value, (list, tuple)):
        return len(value)
    return 0


# Kind discriminator → renderer method. Built once at import time. The values
# are unbound methods invoked as `handler(self, node, fields)` in `render_kind`.
#: Kinds whose body IS the node's semantic element, so the a11y projection
#: belongs on that element rather than on the wrapper `<div>`.
#:
#: Three conditions, all required: the body is a SINGLE root element (not a
#: container of siblings, not a label-wrapped control); that element carries
#: native semantics of its own (an interactive role, or a graphic), so `role` /
#: `aria-*` on an ancestor `<div>` is announced against the wrong node; and the
#: element IS the node, with nothing else in the body competing for the
#: accessible name. ``Link`` (``<a>``), ``Button`` (``<button>``) and ``Image``
#: (``<img>``) satisfy all three. The form-field kinds deliberately do not: a
#: ``Select``'s control sits inside a ``<label>`` that already names it.
#:
#: Tag-level by construction — the wrapper must decide before the body is
#: rendered, and the only thing it has then is the kind tag.
#: ``Media`` (fuaran#1076) satisfies all three: a single ``<video>`` / ``<audio>``
#: root, native transport semantics of its own, and nothing else in the body
#: competing for the accessible name. ``Image`` keeps its membership when the
#: caption or expansion wrapper is present — the projection stays on the ``<img>``
#: the attributes describe, which is what the wrapper is wrapped AROUND, and is
#: byte-parity with the reference server renderer.
#: ``Embed`` (fuaran#1111) satisfies the same three: the ``<iframe>`` IS the body
#: root, a frame carries native interactive semantics (it is a focus container a
#: reader tabs into), and nothing else competes for the name. A node-level
#: ``Accessibility.Label`` overrides the spec's own ``title`` on ``Media``'s
#: precedence, which is what a node-level slot is for.
_SEMANTIC_ELEMENT_TAGS = frozenset({"Link", "Button", "Image", "Media", "Embed"})

# ── The node-level tooltip trait (fuaran#1112) ───────────────────────────────
#
# A tooltip is a DESCRIPTION of the node, revealed by the reference stylesheet's
# own hover / focus affordance and announced through ``aria-describedby``. Two
# placement questions follow from one principle, and getting either wrong makes
# the hint reach nobody:
#
#  1. THE ELEMENT THAT CARRIES ``aria-describedby`` MUST BE THE ELEMENT THAT
#     TAKES FOCUS. A description on a wrapper the keyboard never lands on is
#     announced on no interaction at all; a description on a control while the
#     wrapper is the focus stop is the same failure with the parts swapped.
#  2. A node whose body is not a focus stop therefore needs one —
#     ``tabindex="0"`` on the wrapper — or the hint is pointer-only (WCAG 2.1.1).
#
# So the two decisions are ONE decision, and both reference renderers take it the
# same way: where the projection forwards to a semantic element that takes focus
# NATIVELY, the description rides that element and the wrapper stays untouched;
# everywhere else the description rides the wrapper and the wrapper takes the stop.
#
# ``Image`` is the case that shows why this is not simply membership of
# ``_SEMANTIC_ELEMENT_TAGS``: it forwards, and ``<img>`` takes no focus, so an
# image with a hint needs the wrapper stop AND the wrapper description — the
# pair, or neither.
_TOOLTIP_FOCUSABLE_TAGS = frozenset({"Button", "Link", "Media", "Embed"})


def _tooltip_hint_id(node_id: str) -> str:
    """The DOM id of the hint element a node's tooltip renders as.

    Derived from the node id so every host, and any consumer reading the emitted
    markup, computes the same string without a second identifier on the wire.
    """
    return node_id + "-tooltip"


def _tooltip_rides_semantic_element(tag: str | None) -> bool:
    """Does the hint's ``aria-describedby`` ride the kind's own semantic element?

    True exactly when the projection forwards AND the forwarded-to element is a
    native focus stop. A narrow allow-list rather than an exhaustive match,
    deliberately: the DEFAULT answer (describe the wrapper, and give the wrapper a
    focus stop) is always reachable and correct, at worst one redundant tab stop
    on a node the author chose to annotate. The opposite default silently loses
    the keyboard route altogether, which nothing downstream would report.
    """
    return tag in _SEMANTIC_ELEMENT_TAGS and tag in _TOOLTIP_FOCUSABLE_TAGS


def _with_tooltip_described_by(hint_id: str, attrs: list[tuple[str, str]]) -> list[tuple[str, str]]:
    """Merge a tooltip's hint id into an attribute list's ``aria-describedby``.

    Appended, never substituted: ``aria-describedby`` is an ID LIST, and a node
    that declares ``accessibility.describedBy`` AND carries a hint has said two
    different things a reader is owed both of. Overwriting would silently drop
    whichever the renderer happened to apply second.
    """
    for index, (key, value) in enumerate(attrs):
        if key == "aria-describedby":
            return [*attrs[:index], (key, value + " " + hint_id), *attrs[index + 1 :]]
    return [*attrs, ("aria-describedby", hint_id)]


#: fuaran#1077 — the presentation tokens' class mappings. Absent from each map is
#: ``Natural``, which emits NO class on either axis, so a pre-phase image's class
#: attribute is byte-identical to what it always was.
_IMAGE_FIT_CLASS = {"Cover": " fuaran-image-fit-cover", "Contain": " fuaran-image-fit-contain"}
_IMAGE_ASPECT_CLASS = {
    "Square": " fuaran-image-aspect-square",
    "FourThree": " fuaran-image-aspect-four-three",
    "ThreeTwo": " fuaran-image-aspect-three-two",
    "SixteenNine": " fuaran-image-aspect-sixteen-nine",
}


def _tree_item_expanded(key_named: bool, expanded: frozenset[str], row_id: str, has_children: bool) -> bool:
    """Is this row's SUBTREE shown? (fuaran#1120)

    A tree naming NO expansion key renders FULLY EXPANDED, and that is the
    grid-behaviour rule read straight across rather than a special case: a grid
    with no sort state key still honours its declared order, because an initial
    presentation without interactive re-ordering is a legitimate shape. The same
    sentence with "expansion" in it gives a static, fully-visible hierarchy —
    which is what a document that never asked for a toggle means, and the only
    reading under which such a tree shows its content at all.
    """
    return has_children and (not key_named or row_id in expanded)


def _visible_tree_items(key_named: bool, expanded: frozenset[str], rows: Sequence[Value]) -> list[str]:
    """Every row a reader can currently SEE, in document order: the roots, and the
    descendants of every open row."""
    out: list[str] = []
    for row in rows:
        if not isinstance(row, Obj):
            continue
        row_id = row.fields.get("id")
        row_id = row_id if isinstance(row_id, str) else ""
        out.append(row_id)
        children = row.fields.get("children")
        child_rows = children.items if isinstance(children, Arr) else []
        if _tree_item_expanded(key_named, expanded, row_id, bool(child_rows)):
            out.extend(_visible_tree_items(key_named, expanded, child_rows))
    return out


def _focusable_tree_item(
    key_named: bool, expanded: frozenset[str], selected: str | None, rows: Sequence[Value]
) -> str | None:
    """Which row carries ``tabindex="0"`` (fuaran#1120).

    The WAI-ARIA tree pattern is ONE tab stop, not one per row, so exactly one
    visible row is in the sequential focus order and the arrow keys move within
    the widget. That is the property no ``List`` + ``Disclosure`` composition has,
    and it is computed off STATE alone so a server rendering and a client's first
    frame put it on the same row.

    The SELECTED row wins when it is visible; otherwise the FIRST visible row
    does. A selection scrolled out of view by its parent being closed is not a
    focus target — tabbing into the widget must land somewhere the reader can see.
    """
    visible = _visible_tree_items(key_named, expanded, rows)
    if selected is not None and selected in visible:
        return selected
    return visible[0] if visible else None


_KindHandler = Callable[["Renderer", Node, dict[str, Value]], str]

_DISPATCH: dict[str, _KindHandler] = {
    "Box": Renderer._box,
    "SplitPanel": Renderer._split_panel,
    "Tabs": Renderer._tabs,
    "SummaryList": Renderer._summary_list,
    "Disclosure": Renderer._disclosure,
    "Stepper": Renderer._stepper,
    "Modal": Renderer._modal,
    "ScrollArea": Renderer._scroll_area,
    "Heading": Renderer._heading,
    "Markdown": Renderer._markdown,
    "Metric": Renderer._metric,
    "Badge": Renderer._badge,
    "Callout": Renderer._callout,
    "Progress": Renderer._progress,
    "Skeleton": Renderer._skeleton,
    "Icon": Renderer._icon,
    "Sparkline": Renderer._sparkline,
    "LabelValueRow": Renderer._label_value_row,
    "Fact": Renderer._fact,
    "Link": Renderer._link,
    "Image": Renderer._image,
    "Media": Renderer._media,
    "Embed": Renderer._embed,
    "Tree": Renderer._tree,
    "List": Renderer._list,
    "Toast": Renderer._toast,
    "CodeBlock": Renderer._code_block,
    "Math": Renderer._math,
    "Drawing": Renderer._drawing,
    "Button": Renderer._button,
    "Select": Renderer._select,
    "Form": Renderer._form,
    "Filters": Renderer._filters,
    "FileUpload": Renderer._file_upload,
    "Table": Renderer._table,
    "DataGrid": Renderer._data_grid,
    "Chart": Renderer._chart,
    "Map": Renderer._map,
    "ErrorBoundary": Renderer._error_boundary,
    "Switch": Renderer._switch,
    "FragmentDecl": Renderer._fragment_decl,
    "FragmentRef": Renderer._fragment_ref,
    "Custom": Renderer._custom,
}


def render_html(
    node: Node,
    sources: BindingSourcesLike | None = None,
    egress_policy: EgressPolicy = DENY_NON_LOCAL_EGRESS,
) -> str:
    """Render a decoded :class:`~fuaran_ui.model.Node` tree to a body-fragment HTML string.

    ``sources`` is an optional host-supplied binding map (binding key → value)
    used to resolve non-``Static`` bindings; the headless baseline works with no
    sources, resolving ``Static`` bindings and placeholdering the rest.

    ``egress_policy`` is the ambient destination policy every ``href`` / ``src``
    on the emitted tree is checked against (WIRE_FORMAT §14.1). It **defaults to
    deny** — see :class:`Renderer` for why, and for what a host meets on
    adoption. A host that wants a wider posture declares it BY NAME::

        from fuaran_ui.renderer import render_html
        from fuaran_ui.renderer.egress import (
            DENY_NON_LOCAL_EGRESS, EgressClass, HostSuffix, allow_origin,
        )

        policy = allow_origin(HostSuffix("cdn.example"), [EgressClass.MEDIA], DENY_NON_LOCAL_EGRESS)
        html = render_html(tree, sources, egress_policy=policy)

    A keyword argument rather than a second entry point, matching this host's
    existing ``sources`` shape: the parameter IS the declaration, and it is
    greppable at the call site either way.
    """
    fragments: dict[str, Node] = {}
    _collect_fragments(node, fragments)
    # WIRE_FORMAT §24.4 — the whole tree's ``Binding.State`` declarations seed
    # their slots BEFORE any binding resolves, so a reader that carries no data
    # of its own reads what a sibling declared. Laid UNDER the caller's own
    # sources: a seed is never an override. See :mod:`fuaran_ui.renderer.seeds`.
    seeded = with_state_seeds(node, sources)
    return Renderer(seeded, fragments, egress_policy).render_node(node)
